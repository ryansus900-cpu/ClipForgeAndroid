#!/usr/bin/env python3
"""Report actual APK size and compare against ClipForge's 67 MB budget."""
from pathlib import Path
import sys

LIMIT = 67 * 1024 * 1024
apk = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("app/build/outputs/apk/release/app-release.apk")
if not apk.exists():
    print("APK not found:", apk)
    print("Build first: ./gradlew :app:assembleRelease")
    print("No measured APK size is available yet; this script will report it after a build.")
    sys.exit(2)
size = apk.stat().st_size
print(f"APK: {apk}")
print(f"Size: {size / 1024 / 1024:.2f} MiB ({size:,} bytes)")
print(f"Budget: 67.00 MiB ({LIMIT:,} bytes)")
print(f"Remaining: {(LIMIT-size)/1024/1024:.2f} MiB")
print("PASS" if size <= LIMIT else "FAIL: APK exceeds target")
sys.exit(0 if size <= LIMIT else 1)
