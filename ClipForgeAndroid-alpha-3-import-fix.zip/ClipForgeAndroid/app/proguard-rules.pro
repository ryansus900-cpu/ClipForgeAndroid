# Room and Hilt use generated code. Keep model names for reflection-based JSON/API adapters.
-keepattributes Signature,*Annotation*
-keep class com.clipforge.app.data.** { *; }
# Keep native/third-party model rules scoped here when those integrations are added.
