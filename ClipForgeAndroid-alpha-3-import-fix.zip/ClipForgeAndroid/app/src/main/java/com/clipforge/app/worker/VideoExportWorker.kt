package com.clipforge.app.worker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.OverlayEffect
import androidx.room.Room
import com.clipforge.app.CaptionOverlay
import com.clipforge.app.data.ClipForgeDatabase
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import org.json.JSONArray
import org.json.JSONObject

@UnstableApi
class VideoExportWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo("Preparing export…", 0)


    override suspend fun doWork(): Result {
        val input = inputData.getString(KEY_URI)?.let(Uri::parse) ?: return Result.failure()
        val startMs = inputData.getLong(KEY_START_MS, 0L).coerceAtLeast(0L)
        val endMs = inputData.getLong(KEY_END_MS, 0L)
        if (endMs <= startMs) return Result.failure(androidx.work.Data.Builder().putString(KEY_ERROR, "Invalid clip range: end must be after start.").build())
        val vertical = inputData.getBoolean(KEY_VERTICAL, true)
        val resolution = inputData.getInt(KEY_RESOLUTION, 1080).let { if (it <= 720) 720 else 1080 }
        val zoom = inputData.getFloat(KEY_ZOOM, 1f).coerceIn(1f, 3f)
        val burnCaptions = inputData.getBoolean(KEY_BURN_CAPTIONS, true)
        val cleanupSettingsJson = inputData.getString(KEY_CLEANUP_SETTINGS).orEmpty()

        val tempDir = File(applicationContext.cacheDir, "clipforge-export").apply { mkdirs() }
        val tempFile = File(tempDir, "export-${id}.mp4")
        tempFile.delete()
        try {
            setForeground(foregroundInfo("Exporting video…", 0))
            val cutRanges = selectedCleanupRanges(cleanupSettingsJson)
                .map { (cutStart, cutEnd) -> maxOf(startMs, cutStart) to minOf(endMs, cutEnd) }
                .filter { (a, b) -> b > a }
                .sortedBy { it.first }
            val keptRanges = buildKeptRanges(startMs, endMs, cutRanges)
            if (keptRanges.isEmpty()) return Result.failure(androidx.work.Data.Builder().putString(KEY_ERROR, "Nothing left to export after cleanup cuts.").build())

            val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
                .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7)
                .build()
            val project = try {
                withContext(Dispatchers.IO) { db.projectDao().findByUri(input.toString()) }
            } finally { db.close() }
            val editedItems = keptRanges.map { (segmentStart, segmentEnd) ->
                val clipping = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(segmentStart)
                    .setEndPositionMs(segmentEnd)
                    .build()
                val item = MediaItem.Builder().setUri(input).setClippingConfiguration(clipping).build()
                val videoEffects = mutableListOf<androidx.media3.common.Effect>()
                if (vertical) videoEffects += Presentation.createForWidthAndHeight(resolution, resolution * 16 / 9, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
                else videoEffects += Presentation.createForWidthAndHeight(resolution * 16 / 9, resolution, Presentation.LAYOUT_SCALE_TO_FIT)
                if (zoom > 1.001f) videoEffects += ScaleAndRotateTransformation.Builder().setScale(zoom, zoom).build()
                if (burnCaptions && project?.transcriptJson?.isNotBlank() == true) {
                    videoEffects += OverlayEffect(listOf(CaptionOverlay(project.transcriptJson, project.subtitleSettingsJson, segmentStart)))
                }
                EditedMediaItem.Builder(item).setEffects(Effects(emptyList(), videoEffects)).build()
            }
            val sequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedItems)
            val composition = Composition.Builder(sequence).build()
            exportWithProgress(composition, tempFile)
            if (!tempFile.exists() || tempFile.length() < 1024L) {
                return Result.failure(androidx.work.Data.Builder().putString(KEY_ERROR, "Export finished without a valid MP4 output file.").build())
            }
            val savedUri = saveToGalleryOrAppFolder(tempFile)
            notifyFinished("Export complete · saved to Movies/ClipForge")
            return Result.success(androidx.work.Data.Builder().putString(KEY_RESULT_URI, savedUri.toString()).build())
        } catch (e: Exception) {
            val message = e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName
            return Result.failure(androidx.work.Data.Builder().putString(KEY_ERROR, "Video export failed: $message").build())
        } finally {
            tempFile.delete()
        }
    }

    private fun selectedCleanupRanges(settingsJson: String): List<Pair<Long, Long>> = runCatching {
        val root = JSONObject(settingsJson)
        val details = root.optJSONArray("cleanupCutDetails") ?: JSONArray()
        val selected = root.optJSONArray("cleanupCuts") ?: JSONArray()
        (0 until selected.length()).mapNotNull { idx ->
            val detailIndex = selected.optInt(idx, -1)
            val detail = details.optJSONObject(detailIndex) ?: return@mapNotNull null
            val a = (detail.optDouble("start", -1.0) * 1000).toLong()
            val b = (detail.optDouble("end", -1.0) * 1000).toLong()
            if (a >= 0 && b > a) a to b else null
        }
    }.getOrDefault(emptyList())

    private fun buildKeptRanges(startMs: Long, endMs: Long, cuts: List<Pair<Long, Long>>): List<Pair<Long, Long>> {
        val merged = mutableListOf<Pair<Long, Long>>()
        cuts.sortedBy { it.first }.forEach { (a, b) ->
            val start = a.coerceIn(startMs, endMs)
            val end = b.coerceIn(startMs, endMs)
            if (end <= start) return@forEach
            val last = merged.lastOrNull()
            if (last != null && start <= last.second) merged[merged.lastIndex] = last.first to maxOf(last.second, end)
            else merged += start to end
        }
        val kept = mutableListOf<Pair<Long, Long>>()
        var cursor = startMs
        merged.forEach { (cutStart, cutEnd) ->
            if (cutStart > cursor) kept += cursor to cutStart
            cursor = maxOf(cursor, cutEnd)
        }
        if (cursor < endMs) kept += cursor to endMs
        return kept.filter { (a, b) -> b - a >= 100 }
    }

    private suspend fun exportWithProgress(composition: Composition, output: File) = withContext(Dispatchers.Main.immediate) {
        var finished = false
        var failure: Exception? = null
        val startedAt = SystemClock.elapsedRealtime()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult) {
                finished = true
            }
            override fun onError(composition: androidx.media3.transformer.Composition, exportResult: androidx.media3.transformer.ExportResult, exportException: androidx.media3.transformer.ExportException) {
                failure = exportException
                finished = true
            }
        }
        val transformer = Transformer.Builder(applicationContext)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(listener)
            .build()
        transformer.start(composition, output.absolutePath)
        val holder = ProgressHolder()
        try {
            while (!finished) {
                if (SystemClock.elapsedRealtime() - startedAt > EXPORT_TIMEOUT_MS) {
                    transformer.cancel()
                    throw IllegalStateException("Export timed out after 30 minutes. Try a shorter clip or lower resolution.")
                }
                val state = transformer.getProgress(holder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val pct = holder.progress.coerceIn(0, 100)
                    setProgress(androidx.work.Data.Builder().putInt(KEY_PROGRESS, pct).build())
                    setForeground(foregroundInfo("Exporting video…", pct))
                }
                delay(700)
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            transformer.cancel()
            throw cancelled
        }
        failure?.let { throw it }
    }

    private fun saveToGalleryOrAppFolder(source: File): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "ClipForge_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipForge")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = applicationContext.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Unable to create gallery output")
            try {
                resolver.openOutputStream(uri)?.use { output -> FileInputStream(source).use { it.copyTo(output) } }
                    ?: error("Unable to open gallery output stream")
                values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        }
        val folder = applicationContext.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
            ?: applicationContext.filesDir
        val destination = File(folder, "ClipForge_${System.currentTimeMillis()}.mp4")
        FileInputStream(source).use { input -> FileOutputStream(destination).use { input.copyTo(it) } }
        return Uri.fromFile(destination)
    }


    private fun notifyFinished(message: String) {
        val channelId = "clipforge_export"
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("ClipForge export complete")
            .setContentText(message)
            .setOngoing(false)
            .build()
        manager.notify(7301, notification)
    }

    private fun foregroundInfo(text: String, progress: Int): ForegroundInfo {
        val channelId = "clipforge_export"
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channelId, "ClipForge exports", NotificationManager.IMPORTANCE_LOW))
        }
        val notification: Notification = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("ClipForge")
            .setContentText(if (progress > 0) "$text $progress%" else text)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()
        return ForegroundInfo(7301, notification)
    }

    companion object {
        const val KEY_URI = "source_uri"
        const val KEY_START_MS = "start_ms"
        const val KEY_END_MS = "end_ms"
        const val KEY_VERTICAL = "vertical"
        const val KEY_ZOOM = "zoom"
        const val KEY_BURN_CAPTIONS = "burn_captions"
        const val KEY_CLEANUP_SETTINGS = "cleanup_settings_json"
        const val KEY_RESOLUTION = "resolution"
        const val KEY_PROGRESS = "progress"
        const val KEY_RESULT_URI = "result_uri"
        const val KEY_ERROR = "error"
        private const val EXPORT_TIMEOUT_MS = 30L * 60L * 1000L
    }
}
