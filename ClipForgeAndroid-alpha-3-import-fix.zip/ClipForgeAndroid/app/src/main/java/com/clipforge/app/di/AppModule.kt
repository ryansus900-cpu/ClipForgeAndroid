package com.clipforge.app.di

import android.content.Context
import androidx.room.Room
import com.clipforge.app.data.ClipForgeDatabase
import com.clipforge.app.data.ProjectDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton fun database(@ApplicationContext context: Context): ClipForgeDatabase =
        Room.databaseBuilder(context, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7).build()
    @Provides fun projectDao(db: ClipForgeDatabase): ProjectDao = db.projectDao()
}
