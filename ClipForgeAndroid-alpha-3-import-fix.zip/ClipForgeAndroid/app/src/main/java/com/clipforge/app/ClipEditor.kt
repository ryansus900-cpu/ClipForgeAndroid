package com.clipforge.app

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONObject
import org.json.JSONArray

private data class TimelineWord(val text: String, val start: Float, val end: Float)

@Composable
fun ClipEditorScreen(
    videoUri: Uri,
    candidateStart: Float,
    candidateEnd: Float,
    savedSettings: String = "",
    transcriptJson: String = "",
    onSave: (String) -> Unit,
    onExport: (Float, Float, Float, String, Boolean, Int) -> Unit = { _, _, _, _, _, _ -> },
    onClose: () -> Unit
) {
    val defaults = remember(savedSettings, candidateStart, candidateEnd) {
        runCatching { JSONObject(savedSettings) }.getOrNull()
    }
    val originalStart = candidateStart.coerceAtLeast(0f)
    val originalEnd = candidateEnd.coerceAtLeast(originalStart + 1f)
    var trimStart by remember { mutableFloatStateOf((defaults?.optDouble("start", originalStart.toDouble())?.toFloat() ?: originalStart).coerceIn(originalStart, originalEnd - .25f)) }
    var trimEnd by remember { mutableFloatStateOf((defaults?.optDouble("end", originalEnd.toDouble())?.toFloat() ?: originalEnd).coerceIn(trimStart + .25f, originalEnd)) }
    var zoom by remember { mutableFloatStateOf(defaults?.optDouble("zoom", 1.0)?.toFloat()?.coerceIn(1f, 3f) ?: 1f) }
    var framing by remember { mutableStateOf(defaults?.optString("framing", "vertical_crop") ?: "vertical_crop") }
    var saved by remember { mutableStateOf(false) }
    var dragMode by remember { mutableStateOf("") }
    var burnCaptions by remember { mutableStateOf(true) }
    var exportResolution by remember(savedSettings) { mutableIntStateOf(JSONObject(savedSettings).optInt("exportResolution", 1080).coerceIn(720, 1080)) }
    val timelineWords = remember(transcriptJson) {
        runCatching {
            val arr = JSONObject(transcriptJson).optJSONArray("words") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                arr.optJSONObject(i)?.let { w ->
                    val text = w.optString("text").trim()
                    val start = w.optDouble("start", -1.0).toFloat()
                    val end = w.optDouble("end", -1.0).toFloat()
                    if (text.isNotBlank() && start >= 0f && end > start) TimelineWord(text, start, end) else null
                }
            }
        }.getOrDefault(emptyList())
    }
    val selectedCuts = remember(savedSettings) {
        runCatching {
            val root = JSONObject(savedSettings)
            val details = root.optJSONArray("cleanupCutDetails") ?: JSONArray()
            val selected = root.optJSONArray("cleanupCuts") ?: JSONArray()
            (0 until selected.length()).mapNotNull { i ->
                details.optJSONObject(selected.optInt(i, -1))?.let { d ->
                    val a = d.optDouble("start", -1.0).toFloat()
                    val b = d.optDouble("end", -1.0).toFloat()
                    if (a >= 0f && b > a) a to b else null
                }
            }
        }.getOrDefault(emptyList())
    }
    var timelinePosition by remember(savedSettings, trimStart) { mutableFloatStateOf((defaults?.optDouble("playhead", trimStart.toDouble())?.toFloat() ?: trimStart).coerceIn(trimStart, trimEnd)) }
    var playbackStatus by remember { mutableStateOf("Preview ready") }
    val context = androidx.compose.ui.platform.LocalContext.current
    var waveformData by remember(videoUri) { mutableStateOf<com.clipforge.app.data.AudioWaveformData?>(null) }
    var waveformMessage by remember(videoUri) { mutableStateOf("Connecting to audio analyzer…") }
    LaunchedEffect(videoUri) {
        waveformMessage = "Analyzing audio waveform…"
        try {
            waveformData = com.clipforge.app.data.AudioWaveformProvider(context).load(videoUri)
            waveformMessage = if (waveformData?.amplitudes?.isNotEmpty() == true) "Real audio waveform · ${waveformData!!.amplitudes.size} samples" else "No waveform samples returned"
        } catch (e: Exception) {
            waveformMessage = e.message?.take(120) ?: "Waveform analysis unavailable"
        }
    }
    val clipDuration = (trimEnd - trimStart).coerceAtLeast(.25f)
    val waveformBins = remember(waveformData, trimStart, trimEnd) {
        val data = waveformData ?: return@remember emptyList<Float>()
        val full = data.amplitudes
        if (full.isEmpty() || data.durationSeconds <= 0f) return@remember emptyList<Float>()
        val startIndex = (trimStart / data.durationSeconds * full.size).toInt().coerceIn(0, full.size - 1)
        val endIndex = (trimEnd / data.durationSeconds * full.size).toInt().coerceIn(startIndex + 1, full.size)
        val selected = full.subList(startIndex, endIndex)
        val target = minOf(650, selected.size).coerceAtLeast(1)
        if (selected.size <= target) selected.toList() else List(target) { i ->
            val from = i * selected.size / target
            val to = ((i + 1) * selected.size / target).coerceAtLeast(from + 1).coerceAtMost(selected.size)
            selected.subList(from, to).maxOrNull() ?: 0f
        }
    }

    val player = remember(videoUri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUri))
            prepare()
            playWhenReady = false
            seekTo((originalStart * 1000).toLong())
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    // Preview applies the same approved cleanup ranges used by the export worker.
    // Source timestamps remain absolute, so the timeline playhead still represents the original video.
    LaunchedEffect(player, trimStart, trimEnd, selectedCuts) {
        val startMs = (trimStart * 1000f).toLong()
        val endMs = (trimEnd * 1000f).toLong()
        if (player.currentPosition < startMs || player.currentPosition > endMs) player.seekTo(startMs)
        while (true) {
            val currentMs = player.currentPosition
            val activeCut = selectedCuts.firstOrNull { (a, b) -> currentMs >= (a * 1000f).toLong() && currentMs < (b * 1000f).toLong() }
            if (player.isPlaying && activeCut != null) {
                val jumpMs = (activeCut.second * 1000f).toLong().coerceIn(startMs, endMs)
                player.seekTo(jumpMs)
                timelinePosition = jumpMs / 1000f
                playbackStatus = "Skipped approved cleanup cut"
            } else if (player.isPlaying && currentMs >= endMs) {
                player.pause()
                player.seekTo(endMs)
                timelinePosition = trimEnd
                playbackStatus = "Reached trim end"
            } else {
                timelinePosition = (currentMs / 1000f).coerceIn(trimStart, trimEnd)
            }
            delay(80)
        }
    }
    LaunchedEffect(trimStart, trimEnd) {
        timelinePosition = timelinePosition.coerceIn(trimStart, trimEnd)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B12)).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("CLIP EDITOR", color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Close") }
        }
        Text("Trim, preview, and frame your selected moment", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.Black), modifier = Modifier.width(230.dp).height(410.dp)) {
                AndroidView(factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = true
                        resizeMode = if (framing == "vertical_crop") androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM else androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                }, update = { view ->
                    view.player = player
                    view.resizeMode = if (framing == "vertical_crop") androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM else androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                }, modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            var target = timelinePosition.coerceIn(trimStart, trimEnd - .05f)
            selectedCuts.firstOrNull { (a, b) -> target >= a && target < b }?.let { cut -> target = cut.second.coerceAtMost(trimEnd - .05f) }
            player.seekTo((target * 1000).toLong())
            player.play()
            playbackStatus = if (selectedCuts.isEmpty()) "Playing preview" else "Playing cleaned preview · approved cuts skip during playback"
        }, modifier = Modifier.fillMaxWidth()) { Text(if (selectedCuts.isEmpty()) "Play from timeline position" else "Play cleaned preview") }
        Text(playbackStatus, color = Color(0xFF8CE6A6), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text("TIMELINE · ${"%.1f".format(trimStart)}s – ${"%.1f".format(trimEnd)}s", color = Color.White, style = MaterialTheme.typography.labelLarge)
        Canvas(Modifier.fillMaxWidth().height(100.dp).background(Color(0xFF181622)).pointerInput(trimStart, trimEnd, waveformBins) {
            detectDragGestures(onDragStart = { start ->
                val xRatio = (start.x / size.width).coerceIn(0f, 1f)
                dragMode = when {
                    xRatio < .10f -> "start"
                    xRatio > .90f -> "end"
                    else -> "play"
                }
            }, onDragEnd = { dragMode = "" }) { change, _ ->
                val ratio = (change.position.x / size.width).coerceIn(0f, 1f)
                when (dragMode) {
                    "start" -> { trimStart = (originalStart + ratio * (originalEnd - originalStart)).coerceAtMost(trimEnd - .25f); timelinePosition = timelinePosition.coerceAtLeast(trimStart); player.pause(); player.seekTo((timelinePosition * 1000).toLong()); saved = false }
                    "end" -> { trimEnd = (originalStart + ratio * (originalEnd - originalStart)).coerceAtLeast(trimStart + .25f); timelinePosition = timelinePosition.coerceAtMost(trimEnd); player.pause(); player.seekTo((timelinePosition * 1000).toLong()); saved = false }
                    else -> { timelinePosition = trimStart + ratio * clipDuration; player.pause(); player.seekTo((timelinePosition * 1000).toLong()); playbackStatus = "Timeline scrubbed" }
                }
            }
        }) {
            val total = clipDuration
            val trackTop = size.height * .22f
            val trackBottom = size.height * .84f
            drawRect(Color(0xFF302C3C), topLeft = Offset(0f, trackTop), size = androidx.compose.ui.geometry.Size(size.width, trackBottom - trackTop))
            if (waveformBins.isNotEmpty()) {
                val step = size.width / waveformBins.size.toFloat()
                waveformBins.forEachIndexed { index, amplitude ->
                    val h = (amplitude.coerceAtLeast(.035f) * (trackBottom - trackTop) * .92f)
                    val x = index * step
                    drawRect(Color(0xFF59C3B2), topLeft = Offset(x, (size.height - h) / 2f), size = androidx.compose.ui.geometry.Size(step.coerceAtLeast(1f), h))
                }
            } else {
                drawRect(Color(0xFF464253), topLeft = Offset(0f, trackTop), size = androidx.compose.ui.geometry.Size(size.width, trackBottom-trackTop))
            }
            timelineWords.filter { it.end > trimStart && it.start < trimEnd }.forEach { word ->
                val left = ((word.start - trimStart) / total).coerceIn(0f, 1f) * size.width
                val right = ((word.end - trimStart) / total).coerceIn(0f, 1f) * size.width
                val barHeight = 5f + ((word.text.length % 5) * 3f)
                drawRect(Color(0xFF8D72D9), topLeft = androidx.compose.ui.geometry.Offset(left, trackBottom - barHeight), size = androidx.compose.ui.geometry.Size((right-left).coerceAtLeast(2f), barHeight))
            }
            selectedCuts.forEach { (a, b) ->
                val left = ((a - trimStart) / total).coerceIn(0f, 1f) * size.width
                val right = ((b - trimStart) / total).coerceIn(0f, 1f) * size.width
                if (right > left) drawRect(Color(0x88F05A5A), topLeft = androidx.compose.ui.geometry.Offset(left, trackTop), size = androidx.compose.ui.geometry.Size(right-left, trackBottom-trackTop))
            }
            val playX = ((timelinePosition - trimStart) / total).coerceIn(0f, 1f) * size.width
            drawLine(Color.White, Offset(playX, 0f), Offset(playX, size.height), strokeWidth = 3f)
            drawLine(Color(0xFFFFD166), Offset(4f, 0f), Offset(4f, size.height), strokeWidth = 5f)
            drawLine(Color(0xFFFFD166), Offset(size.width - 4f, 0f), Offset(size.width - 4f, size.height), strokeWidth = 5f)
        }
        Text(waveformMessage, color = Color(0xFFB7B3C4), fontSize = 11.sp)
        Text("Waveform = audio RMS · purple = transcript · red = approved cut · yellow edges = draggable trim", color = Color(0xFFB7B3C4), fontSize = 11.sp)
        Text(if (selectedCuts.isEmpty()) "No saved cleanup cuts selected. Use Smart Cleanup and save cuts to preview/export them." else "${selectedCuts.size} saved cleanup cut(s) · skipped in preview and removed during export", color = Color(0xFF8CE6A6), fontSize = 11.sp)
        Slider(value = timelinePosition.coerceIn(trimStart, trimEnd), onValueChange = { timelinePosition = it; player.pause(); player.seekTo((it * 1000).toLong()); playbackStatus = "Timeline scrubbed" }, valueRange = trimStart..trimEnd)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${timelinePosition.toInt()} sec", color = Color.White, fontSize = 12.sp)
            Text("${trimEnd.toInt()} sec", color = Color(0xFFB7B3C4), fontSize = 12.sp)
        }
        if (timelineWords.isNotEmpty()) {
            Text("TRANSCRIPT TIMELINE", color = Color.White, style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(timelineWords.filter { it.end >= trimStart && it.start <= trimEnd }) { word ->
                    AssistChip(onClick = { timelinePosition = word.start.coerceIn(trimStart, trimEnd); player.pause(); player.seekTo((timelinePosition * 1000).toLong()); playbackStatus = "Jumped to transcript word" }, label = { Text(word.text) })
                }
            }
        } else Text("Transcribe this project to show timed word markers on the timeline.", color = Color(0xFFB7B3C4), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text("Clip start · ${trimStart.toInt()} sec", color = Color.White)
        Slider(value = trimStart, onValueChange = { newValue -> trimStart = newValue.coerceAtMost(trimEnd - .25f); saved = false }, valueRange = originalStart..(originalEnd - .25f))
        Text("Clip end · ${trimEnd.toInt()} sec", color = Color.White)
        Slider(value = trimEnd, onValueChange = { newValue -> trimEnd = newValue.coerceAtLeast(trimStart + .25f); saved = false }, valueRange = (originalStart + .25f)..originalEnd)
        Text("Duration · ${(trimEnd - trimStart).toInt()} seconds", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(10.dp))
        Text("FRAME", color = Color.White, style = MaterialTheme.typography.labelLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = framing == "vertical_crop", onClick = { framing = "vertical_crop"; saved = false }, label = { Text("9:16 crop") })
            FilterChip(selected = framing == "fit", onClick = { framing = "fit"; saved = false }, label = { Text("Fit source") })
        }
        Text("Zoom · ${"%.1f".format(zoom)}×", color = Color.White)
        Slider(value = zoom, onValueChange = { zoom = it; saved = false }, valueRange = 1f..3f)
        Text("Zoom is stored as an edit setting. Live zoom rendering is not wired yet; preview currently uses fit or center-crop.", color = Color(0xFFAAA6B8), fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val settings = (defaults ?: JSONObject()).put("start", trimStart).put("end", trimEnd).put("zoom", zoom).put("framing", framing).put("playhead", timelinePosition.coerceIn(trimStart, trimEnd)).put("exportResolution", exportResolution).put("version", 4).toString()
            onSave(settings); saved = true
        }, modifier = Modifier.fillMaxWidth()) { Text("Save clip edits") }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = burnCaptions, onCheckedChange = { burnCaptions = it })
            Text("Burn in captions (if transcript saved)", color = Color.White, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Text("EXPORT STUDIO", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text("Choose output size. Frame rate currently follows the source video; encoder bitrate uses Media3 defaults.", color = Color(0xFFAAA6B8), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            FilterChip(selected = exportResolution == 720, onClick = { exportResolution = 720; saved = false }, label = { Text("720p · Standard") })
            FilterChip(selected = exportResolution == 1080, onClick = { exportResolution = 1080; saved = false }, label = { Text("1080p · High") })
        }
        Text("Output: ${if (framing == "vertical_crop") "${exportResolution} × ${exportResolution * 16 / 9} · 9:16" else "Fit source · max ${exportResolution}p"}", color = Color(0xFFB7B3C4), fontSize = 12.sp)
        Button(onClick = { onExport(trimStart, trimEnd, zoom, framing, burnCaptions, exportResolution) }, modifier = Modifier.fillMaxWidth()) { Text("Export MP4 · ${exportResolution}p") }
        if (saved) Text("Edit settings saved to your project.", color = Color(0xFF8CE6A6), modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { onClose() }, modifier = Modifier.fillMaxWidth()) { Text("Return to clip suggestions") }
        Text("Export renders an MP4 with selected trim and framing. When a saved transcript is available and caption burn-in is enabled, captions are rendered into the video.", color = Color(0xFFAAA6B8), fontSize = 12.sp)
    }
}
