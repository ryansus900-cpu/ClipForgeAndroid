package com.clipforge.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Streams the selected video to a user's secured backend. No provider secret is stored in the app. */
class BackendTranscriptionProvider(private val context: Context, private val baseUrl: String) : TranscriptionProvider {
    override suspend fun transcribe(videoUri: String, languageHint: String): TranscriptResult = withContext(Dispatchers.IO) {
        require(baseUrl.isNotBlank()) { "Transcription backend URL is not configured. Set CLIPFORGE_API_BASE in Gradle properties." }
        val allowedHttp = baseUrl.startsWith("http://10.0.2.2") ||
            baseUrl.startsWith("http://localhost") ||
            baseUrl.startsWith("http://127.0.0.1") ||
            baseUrl.matches(Regex("""^http://192\.168\.\d{1,3}\.\d{1,3}(:\d+)?(/.*)?$""")) ||
            baseUrl.matches(Regex("""^http://10\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?(/.*)?$"""))
        require(baseUrl.startsWith("https://") || allowedHttp) {
            "Backend must use HTTPS (HTTP is allowed only for local network / emulator testing)."
        }
        val uri = Uri.parse(videoUri)
        val mime = context.contentResolver.getType(uri) ?: "video/mp4"
        val boundary = "ClipForge-${UUID.randomUUID()}"
        val endpoint = URL(baseUrl.trimEnd('/') + "/api/transcribe")
        val conn = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 600_000
            doOutput = true
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            setRequestProperty("Accept", "application/json")
            setChunkedStreamingMode(1024 * 1024)
        }
        try {
            conn.outputStream.use { out ->
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\n$languageHint\r\n".toByteArray())
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"video\"; filename=\"clipforge-upload\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
                context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out, 1024 * 1024) }
                    ?: throw IllegalStateException("Could not open selected video stream")
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("Transcription service returned HTTP $code: ${body.take(300)}")
            val json = JSONObject(body)
            val language = json.optString("detected_language", "unknown")
            val wordsJson = json.optJSONArray("words") ?: JSONArray()
            val words = (0 until wordsJson.length()).map { i ->
                val w = wordsJson.getJSONObject(i)
                TranscriptWord(w.optString("text"), w.optDouble("start", 0.0), w.optDouble("end", 0.0))
            }
            TranscriptResult(language, words)
        } finally { conn.disconnect() }
    }

}
