package com.clipforge.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.room.Room
import com.clipforge.app.BuildConfig
import com.clipforge.app.data.ClipAnalysisProvider
import com.clipforge.app.data.ClipForgeDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ClipAnalysisWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val uri = inputData.getString(KEY_URI).orEmpty()
        if (uri.isBlank()) return@withContext Result.failure()
        val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7).build()
        try {
            val project = db.projectDao().findByUri(uri) ?: return@withContext Result.retry()
            if (project.transcriptJson.isBlank()) return@withContext Result.failure()
            db.projectDao().saveClipCandidates(project.id, "", "processing")
            val response = ClipAnalysisProvider(BuildConfig.CLIPFORGE_API_BASE)
                .analyze(project.transcriptJson, project.detectedLanguage, inputData.getString(KEY_PROMPT).orEmpty(), inputData.getInt(KEY_COUNT, 8))
            val clips = response.optJSONArray("clips")
            db.projectDao().saveClipCandidates(project.id, clips?.toString().orEmpty(), "complete")
            Result.success()
        } catch (e: IllegalArgumentException) {
            val p = db.projectDao().findByUri(uri); if (p != null) db.projectDao().saveClipCandidates(p.id, "", "error: ${e.message ?: "configuration error"}")
            Result.failure()
        } catch (e: Exception) {
            val p = db.projectDao().findByUri(uri); if (p != null) db.projectDao().saveClipCandidates(p.id, "", "error: ${e.message ?: "analysis failed"}")
            Result.retry()
        } finally { db.close() }
    }
    companion object { const val KEY_URI = "clip_analysis_uri"; const val KEY_PROMPT = "clip_analysis_prompt"; const val KEY_COUNT = "clip_analysis_count" }
}
