package com.clipforge.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Insert suspend fun insert(project: ProjectEntity): Long
    @Query("SELECT * FROM projects ORDER BY createdAtEpochMs DESC") fun observeProjects(): Flow<List<ProjectEntity>>
    @Query("UPDATE projects SET status = :status WHERE id = :id") suspend fun updateStatus(id: Long, status: String)
    @Query("SELECT * FROM projects WHERE sourceUri = :uri LIMIT 1") suspend fun findByUri(uri: String): ProjectEntity?
    @Query("SELECT * FROM projects WHERE sourceUri = :uri LIMIT 1") fun observeByUri(uri: String): Flow<ProjectEntity?>
    @Query("UPDATE projects SET detectedLanguage = :language, transcriptJson = :transcript, transcriptionStatus = :status WHERE id = :id")
    suspend fun saveTranscript(id: Long, language: String, transcript: String, status: String)
    @Query("UPDATE projects SET clipCandidatesJson = :clips, clipAnalysisStatus = :status WHERE id = :id")
    suspend fun saveClipCandidates(id: Long, clips: String, status: String)
    @Query("UPDATE projects SET transcriptJson = :transcript WHERE id = :id")
    suspend fun updateTranscriptJson(id: Long, transcript: String)
    @Query("UPDATE projects SET editSettingsJson = :settings WHERE id = :id")
    suspend fun saveEditSettings(id: Long, settings: String)
    @Query("UPDATE projects SET subtitleSettingsJson = :settings WHERE id = :id")
    suspend fun saveSubtitleSettings(id: Long, settings: String)
    @Query("UPDATE projects SET socialMetadataJson = :metadata WHERE id = :id")
    suspend fun saveSocialMetadata(id: Long, metadata: String)
}
