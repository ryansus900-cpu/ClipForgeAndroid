package com.clipforge.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import android.provider.OpenableColumns
import com.clipforge.app.worker.ImportProjectWorker
import com.clipforge.app.worker.TranscriptionWorker
import com.clipforge.app.worker.ClipAnalysisWorker
import com.clipforge.app.worker.VideoExportWorker
import com.clipforge.app.data.ClipForgeDatabase
import org.json.JSONObject
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import java.util.UUID
import dagger.hilt.android.AndroidEntryPoint
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedVideo = if (intent?.action == Intent.ACTION_SEND) intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) else null
        val db = androidx.room.Room.databaseBuilder(this, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7).build()
        setContent {
            ClipForgeApp(initialUri = sharedVideo,
                onImport = { uri, name -> enqueueImport(uri, name) },
                onTranscribe = { uri -> enqueueTranscription(uri) },
                onAnalyzeClips = { uri, prompt -> enqueueClipAnalysis(uri, prompt) },
                onSaveTranscript = { id, json, style -> lifecycleScope.launch { db.projectDao().updateTranscriptJson(id, json); db.projectDao().saveSubtitleSettings(id, style) } },
                onSaveEditSettings = { id, settings -> lifecycleScope.launch { db.projectDao().saveEditSettings(id, settings) } },
                onSaveMetadata = { id, metadata -> lifecycleScope.launch { db.projectDao().saveSocialMetadata(id, metadata) } },
                onExportClip = { uri, start, end, zoom, framing, burnCaptions, cleanupJson, resolution -> enqueueExport(uri, start, end, zoom, framing, burnCaptions, cleanupJson, resolution) },
                projectFlow = { uri -> db.projectDao().observeByUri(uri) })
        }
    }

    private fun enqueueImport(uri: Uri, name: String): UUID {
        val request = OneTimeWorkRequestBuilder<ImportProjectWorker>()
            .setInputData(workDataOf(ImportProjectWorker.KEY_URI to uri.toString(), ImportProjectWorker.KEY_NAME to name))
            .build()
        WorkManager.getInstance(this).enqueue(request)
        return request.id
    }

    private fun enqueueTranscription(uri: Uri) {
        val request = OneTimeWorkRequestBuilder<TranscriptionWorker>()
            .setInputData(workDataOf(TranscriptionWorker.KEY_URI to uri.toString(), TranscriptionWorker.KEY_LANGUAGE to "auto"))
            .build()
        WorkManager.getInstance(this).enqueue(request)
    }

    private fun enqueueExport(uri: Uri, start: Float, end: Float, zoom: Float, framing: String, burnCaptions: Boolean, cleanupSettingsJson: String, resolution: Int) {
        val request = OneTimeWorkRequestBuilder<VideoExportWorker>()
            .setInputData(workDataOf(
                VideoExportWorker.KEY_URI to uri.toString(),
                VideoExportWorker.KEY_START_MS to (start * 1000).toLong(),
                VideoExportWorker.KEY_END_MS to (end * 1000).toLong(),
                VideoExportWorker.KEY_VERTICAL to (framing == "vertical_crop"),
                VideoExportWorker.KEY_ZOOM to zoom,
                VideoExportWorker.KEY_BURN_CAPTIONS to burnCaptions,
                VideoExportWorker.KEY_CLEANUP_SETTINGS to cleanupSettingsJson,
                VideoExportWorker.KEY_RESOLUTION to resolution
            ))
            .build()
        WorkManager.getInstance(this).enqueue(request)
        android.widget.Toast.makeText(this, "Export queued. Check notifications for progress.", android.widget.Toast.LENGTH_LONG).show()
    }

    private fun enqueueClipAnalysis(uri: Uri, prompt: String) {
        val request = OneTimeWorkRequestBuilder<ClipAnalysisWorker>()
            .setInputData(workDataOf(ClipAnalysisWorker.KEY_URI to uri.toString(), ClipAnalysisWorker.KEY_PROMPT to prompt, ClipAnalysisWorker.KEY_COUNT to 8))
            .build()
        WorkManager.getInstance(this).enqueue(request)
    }

    private fun displayName(uri: Uri): String = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull() ?: "Imported video"
}


private val Ink = Color(0xFF0B0B12)
private val Purple = Color(0xFF9B72F2)
private val CardInk = Color(0xFF191723)

@Composable
fun ClipForgeApp(initialUri: Uri? = null, onImport: (Uri, String) -> Unit = { _, _ -> }, onTranscribe: (Uri) -> Unit = {}, onAnalyzeClips: (Uri, String) -> Unit = { _, _ -> }, onSaveTranscript: (Long, String, String) -> Unit = { _, _, _ -> }, onSaveEditSettings: (Long, String) -> Unit = { _, _ -> }, onSaveMetadata: (Long, String) -> Unit = { _, _ -> }, onExportClip: (Uri, Float, Float, Float, String, Boolean, String, Int) -> Unit = { _, _, _, _, _, _, _, _ -> }, projectFlow: (String) -> kotlinx.coroutines.flow.Flow<com.clipforge.app.data.ProjectEntity?> = { kotlinx.coroutines.flow.flowOf(null) }) {
    var videoUri by remember { mutableStateOf(initialUri) }
    var rightsConfirmed by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(if (initialUri != null) "Shared video received. Confirm usage rights to import." else "Import a video to start your first project") }
    var busy by remember { mutableStateOf(false) }
    var subtitleStudioOpen by remember { mutableStateOf(false) }
    var smartCleanupOpen by remember { mutableStateOf(false) }
    var titleStudioOpen by remember { mutableStateOf(false) }
    var titleClipText by remember { mutableStateOf("") }
    var titleClipCategory by remember { mutableStateOf("Highlight") }
    var selectedClipForEdit by remember { mutableStateOf<JSONObject?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val importedProject by (videoUri?.let { projectFlow(it.toString()) } ?: kotlinx.coroutines.flow.flowOf(null)).collectAsState(initial = null)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            // Keep document access after app restart when the picker provider allows it.
            runCatching {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, flags)
            }
            status = "Video selected. Confirm that you have rights before processing."
            busy = false
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Ink, surface = CardInk)) {
        Scaffold(containerColor = Ink) { padding ->
            if (titleStudioOpen && importedProject != null) {
                TitleStudio(clipText = titleClipText, category = titleClipCategory, detectedLanguage = importedProject!!.detectedLanguage, savedMetadataJson = importedProject!!.socialMetadataJson, onSave = { metadata -> onSaveMetadata(importedProject!!.id, metadata); status = "Social metadata saved to project." }, onClose = { titleStudioOpen = false })
            } else if (selectedClipForEdit != null && videoUri != null && importedProject != null) {
                val clip = selectedClipForEdit!!
                ClipEditorScreen(videoUri = videoUri!!, candidateStart = clip.optDouble("start_seconds", 0.0).toFloat(), candidateEnd = clip.optDouble("end_seconds", 30.0).toFloat(), savedSettings = importedProject!!.editSettingsJson, transcriptJson = importedProject!!.transcriptJson, onSave = { settings ->
                    val combined = runCatching {
                        val updated = JSONObject(settings)
                        val previous = JSONObject(importedProject!!.editSettingsJson)
                        listOf("cleanupCuts", "cleanupCutDetails", "cleanupVersion").forEach { key -> if (previous.has(key)) updated.put(key, previous.get(key)) }
                        updated.toString()
                    }.getOrDefault(settings)
                    onSaveEditSettings(importedProject!!.id, combined)
                }, onExport = { start, end, zoom, framing, burnCaptions, resolution -> onExportClip(videoUri!!, start, end, zoom, framing, burnCaptions, importedProject!!.editSettingsJson, resolution) }, onClose = { selectedClipForEdit = null })
            } else if (smartCleanupOpen && importedProject != null && importedProject!!.transcriptJson.isNotBlank()) {
                SmartCleanupScreen(transcriptJson = importedProject!!.transcriptJson, savedSettingsJson = importedProject!!.editSettingsJson, onSave = { settings -> onSaveEditSettings(importedProject!!.id, settings); status = "Cleanup suggestions saved." }, onClose = { smartCleanupOpen = false })
            } else if (subtitleStudioOpen && importedProject != null && importedProject!!.transcriptJson.isNotBlank()) {
                SubtitleStudio(transcriptJson = importedProject!!.transcriptJson, language = importedProject!!.detectedLanguage, savedSettingsJson = importedProject!!.subtitleSettingsJson, onSave = { json, style -> onSaveTranscript(importedProject!!.id, json, style) }, onClose = { subtitleStudioOpen = false })
            } else Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✦", color = Purple, fontSize = 28.sp)
                    Spacer(Modifier.width(9.dp))
                    Text("ClipForge", color = Color.White, fontSize = 26.sp, style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.weight(1f))
                    Text("ALPHA", color = Purple, fontSize = 11.sp)
                }
                Spacer(Modifier.height(22.dp))
                Text("Long videos.\nShort-form magic.", color = Color.White, fontSize = 29.sp, lineHeight = 34.sp)
                Spacer(Modifier.height(7.dp))
                Text("AI clips · Hindi · English · Hinglish", color = Color(0xFFB7B3C4))
                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = CardInk), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("STEP 1 · IMPORT", color = Purple, style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth(), enabled = !busy) {
                            Icon(Icons.Default.VideoFile, contentDescription = null)
                            Spacer(Modifier.width(8.dp)); Text("Choose video from device")
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(videoUri?.lastPathSegment ?: "No video selected", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = rightsConfirmed, onCheckedChange = { rightsConfirmed = it })
                            Text("I own this content or have permission to process it.", color = Color.White, fontSize = 13.sp)
                        }
                        Button(onClick = {
                            when {
                                videoUri == null -> status = "Choose a video file first."
                                !rightsConfirmed -> status = "Please confirm usage rights before import."
                                else -> {
                                    busy = true
                                    status = "Import queued. ClipForge is checking video metadata and saving your project…"
                                    val uri = videoUri!!
                                    onImport(uri, uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "Video project")
                                    status = "Import request queued. Background inspection may take a moment. After the project appears, you can transcribe it."
                                    busy = false
                                }
                            }
                        }, enabled = videoUri != null && !busy, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Import project")
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = {
                            val selected = videoUri
                            if (selected != null && rightsConfirmed && importedProject != null) {
                                onTranscribe(selected)
                                status = "Transcription queued. It will upload the video to your configured backend and save word timestamps."
                            } else status = "Import the video first, and confirm usage rights, before transcription."
                        }, enabled = videoUri != null && rightsConfirmed && importedProject != null, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Subtitles, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Transcribe video")
                        }
                        importedProject?.let { project ->
                            Spacer(Modifier.height(10.dp))
                            Text("Project ready · Transcription status: ${project.transcriptionStatus}", color = Purple, style = MaterialTheme.typography.labelMedium)
                            if (project.detectedLanguage.isNotBlank()) Text("Detected language: ${project.detectedLanguage}", color = Color.White)
                            if (project.transcriptJson.isNotBlank()) {
                                val transcript = runCatching {
                                    val words = JSONObject(project.transcriptJson).getJSONArray("words")
                                    (0 until words.length()).joinToString(" ") { words.getJSONObject(it).getString("text") }
                                }.getOrDefault("Transcript could not be read")
                                Text("Transcript", color = Color.White, style = MaterialTheme.typography.titleSmall)
                                Text(transcript, color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = { subtitleStudioOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Subtitles, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Open Subtitle Studio") }
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = { smartCleanupOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Smart Cleanup · Review filler & pause cuts") }
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = { titleClipText = transcript; titleClipCategory = "Highlight"; titleStudioOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Title, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Open Title & Packaging Studio") }
                                Spacer(Modifier.height(8.dp))
                                Button(onClick = { onAnalyzeClips(videoUri!!, "") }, modifier = Modifier.fillMaxWidth(), enabled = project.clipAnalysisStatus != "processing") {
                                    Text(if (project.clipAnalysisStatus == "complete") "Re-analyze viral moments" else "Find best moments (AI clip discovery)")
                                }
                                Text("Clip discovery status: ${project.clipAnalysisStatus}", color = Purple, style = MaterialTheme.typography.labelSmall)
                                if (project.editSettingsJson.isNotBlank()) Text("Saved clip-edit recipe: ${project.editSettingsJson}", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.labelSmall)
                                if (project.clipCandidatesJson.isNotBlank()) {
                                    val candidates = runCatching { org.json.JSONArray(project.clipCandidatesJson) }.getOrNull()
                                    if (candidates != null) {
                                        Text("Suggested clips", color = Color.White, style = MaterialTheme.typography.titleSmall)
                                        for (i in 0 until candidates.length()) {
                                            val clip = candidates.optJSONObject(i) ?: continue
                                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF242131))) {
                                                Column(Modifier.padding(10.dp)) {
                                                    Text("${clip.optInt("score")}/100 · ${clip.optString("category")} · ${clip.optString("duration_seconds")} sec", color = Purple, style = MaterialTheme.typography.labelMedium)
                                                    Text(clip.optString("text"), color = Color.White, style = MaterialTheme.typography.bodySmall)
                                                    Text("${clip.optString("start_seconds")}s – ${clip.optString("end_seconds")}s", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.labelSmall)
                                                    Spacer(Modifier.height(6.dp))
                                                    OutlinedButton(onClick = { titleClipText = clip.optString("text", ""); titleClipCategory = clip.optString("category", "Highlight"); titleStudioOpen = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Title, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Title this clip") }
                                                    Spacer(Modifier.height(4.dp))
                                                    OutlinedButton(onClick = { selectedClipForEdit = clip }, modifier = Modifier.fillMaxWidth()) { Text("Edit this clip") }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(status, color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(24.dp))
                Text("YOUR CREATOR WORKFLOW", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                FeatureRow(Icons.Default.AutoAwesome, "AI clip discovery", "5–10 highlight candidates with scores and reasons")
                FeatureRow(Icons.Default.Subtitles, "Subtitle Studio", "20+ styles · word-level captions · Hinglish")
                FeatureRow(Icons.Default.Title, "Auto titles", "Hindi, English and Hinglish title suggestions")
                FeatureRow(Icons.Default.VideoFile, "Export & share", "Vertical 1080p export and creator sharing")
                Spacer(Modifier.height(20.dp))
                Text("Milestone 1 · Import pipeline", color = Purple, style = MaterialTheme.typography.labelLarge)
                Text("Import + metadata inspection are connected. Transcription can now be queued to a configured secure backend; transcript word timestamps and detected language are saved locally. Clip scoring, captions and export remain upcoming.", color = Color(0xFF9692A4), fontSize = 12.sp)
            }
        }
    }
}


@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = CardInk), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Purple)
            Spacer(Modifier.width(12.dp))
            Column { Text(title, color = Color.White); Text(description, color = Color(0xFFAAA6B8), fontSize = 12.sp) }
        }
    }
}
