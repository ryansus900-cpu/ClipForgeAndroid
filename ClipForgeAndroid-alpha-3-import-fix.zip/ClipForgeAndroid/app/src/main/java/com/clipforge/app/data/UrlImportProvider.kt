package com.clipforge.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Calls the ClipForge backend to download a YouTube / TikTok / Instagram video
 * via yt-dlp, then streams the temporary file into the app cache so the rest
 * of the pipeline (import → transcribe → clip) can treat it like a local video.
 */
class UrlImportProvider(
    private val context: Context,
    private val baseUrl: String,
) {
    data class ImportResult(
        val localUri: Uri,
        val title: String,
        val durationSeconds: Double,
        val fileId: String,
    )

    suspend fun importFromUrl(url: String, maxHeight: Int = 720): ImportResult = withContext(Dispatchers.IO) {
        require(baseUrl.isNotBlank()) {
            "Backend URL is not configured. Set CLIPFORGE_API_BASE in Gradle properties."
        }
        require(
            baseUrl.startsWith("https://") ||
                baseUrl.startsWith("http://10.0.2.2") ||
                baseUrl.startsWith("http://localhost")
        ) {
            "Backend must use HTTPS (HTTP is allowed only for local Android emulator testing)."
        }

        val trimmed = url.trim()
        require(trimmed.isNotBlank()) { "Please paste a valid link." }
        require(
            listOf("youtube.com", "youtu.be", "tiktok.com", "instagram.com", "instagr.am")
                .any { trimmed.contains(it, ignoreCase = true) }
        ) {
            "Only YouTube, TikTok and Instagram links are supported."
        }

        // 1) Ask backend to download the video
        val metaEndpoint = URL(baseUrl.trimEnd('/') + "/api/import/url")
        val metaConn = (metaEndpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 30_000
            readTimeout = 900_000 // yt-dlp can take a while
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
        }

        val requestBody = JSONObject()
            .put("url", trimmed)
            .put("max_height", maxHeight)
            .toString()

        val metaJson: JSONObject
        try {
            metaConn.outputStream.use { it.write(requestBody.toByteArray(Charsets.UTF_8)) }
            val code = metaConn.responseCode
            val body = (if (code in 200..299) metaConn.inputStream else metaConn.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw IllegalStateException("Import failed (HTTP $code): ${body.take(350)}")
            }
            metaJson = JSONObject(body)
        } finally {
            metaConn.disconnect()
        }

        val fileId = metaJson.getString("file_id")
        val title = metaJson.optString("title", "Imported video")
        val duration = metaJson.optDouble("duration_seconds", 0.0)
        val downloadPath = metaJson.optString("download_path", "/api/import/$fileId/download")

        // 2) Download the temporary video into app cache
        val downloadUrl = URL(baseUrl.trimEnd('/') + downloadPath)
        val dlConn = (downloadUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 600_000
            setRequestProperty("Accept", "video/*,*/*")
        }

        val cacheDir = File(context.cacheDir, "url_imports").apply { mkdirs() }
        val safeName = title.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(60).ifBlank { "video" }
        val outFile = File(cacheDir, "${fileId.take(8)}_$safeName.mp4")

        try {
            val code = dlConn.responseCode
            if (code !in 200..299) {
                val err = dlConn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw IllegalStateException("Download failed (HTTP $code): ${err.take(300)}")
            }
            dlConn.inputStream.use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output, 1024 * 1024)
                }
            }
        } finally {
            dlConn.disconnect()
        }

        if (!outFile.exists() || outFile.length() < 1024) {
            outFile.delete()
            throw IllegalStateException("Downloaded file is empty or too small")
        }

        ImportResult(
            localUri = Uri.fromFile(outFile),
            title = title,
            durationSeconds = duration,
            fileId = fileId,
        )
    }
}
