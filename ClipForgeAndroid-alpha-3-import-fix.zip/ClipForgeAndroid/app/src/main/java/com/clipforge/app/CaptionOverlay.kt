package com.clipforge.app

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.media3.effect.CanvasOverlay
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min

/** Timed caption overlay rendered into the exported video using Media3's CanvasOverlay. */
class CaptionOverlay(
    transcriptJson: String,
    settingsJson: String,
    private val clipStartMs: Long
) : CanvasOverlay(false) {
    private data class Word(val text: String, val startMs: Long, val endMs: Long)
    private val words: List<Word> = parseWords(transcriptJson)
    private val settings = runCatching { JSONObject(settingsJson) }.getOrNull() ?: JSONObject()
    private val preset = settings.optString("preset", "BOLD_YELLOW").uppercase()
    private val fontSp = settings.optInt("size", 25).coerceIn(16, 40)
    private val position = settings.optString("position", "Bottom").lowercase()
    private val customColor = settings.optString("customColor", "").let { runCatching { android.graphics.Color.parseColor(it) }.getOrNull() }
    private val animation = settings.optString("animation", "NONE").uppercase()
    private val brandText = settings.optString("brandText", "").trim().take(40)
    private val watermarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt(); textAlign = Paint.Align.RIGHT; typeface = Typeface.create("sans-serif", Typeface.BOLD); textSize = 34f; setShadowLayer(4f, 1f, 2f, 0xAA000000.toInt()) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; typeface = fill.typeface }
    private val backdrop = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99000000.toInt() }
    private val textBounds = RectF()

    init { setCanvasSize(1080, 1920) }

    override fun onDraw(canvas: Canvas, presentationTimeUs: Long) {
        if (brandText.isNotEmpty()) canvas.drawText(brandText, 1000f, 1840f, watermarkPaint)
        if (words.isEmpty()) return
        val currentMs = clipStartMs + presentationTimeUs / 1000L
        val activeIndex = words.indexOfFirst { currentMs >= it.startMs && currentMs <= it.endMs }
        if (activeIndex < 0) return
        val chunkStart = (activeIndex / 5) * 5
        val chunkEnd = min(words.size, chunkStart + 5)
        val chunk = words.subList(chunkStart, chunkEnd)
        val activeLocal = activeIndex - chunkStart
        val activeWord = words[activeIndex]
        val wordProgress = ((currentMs - activeWord.startMs).toFloat() / (activeWord.endMs - activeWord.startMs).coerceAtLeast(1L)).coerceIn(0f, 1f)
        val intro = (wordProgress / 0.22f).coerceIn(0f, 1f)
        val animationScale = when (animation) {
            "POP" -> 0.78f + 0.22f * intro
            "BOUNCE" -> if (intro < 0.65f) 0.75f + 0.37f * (intro / 0.65f) else 1.12f - 0.12f * ((intro - 0.65f) / 0.35f)
            else -> 1f
        }
        val animationAlpha = if (animation == "FADE") (intro * 255f).toInt().coerceIn(0, 255) else 255
        val animationShiftY = if (animation == "SLIDE_UP") 45f * (1f - intro) else 0f
        canvas.save()
        canvas.translate(0f, animationShiftY)
        canvas.scale(animationScale, animationScale, 540f, 960f)
        val sizePx = fontSp * 2.45f // designed for 1080x1920 output, maps sp-ish settings to video pixels
        fill.textSize = sizePx
        stroke.textSize = sizePx
        val widthLimit = 930f
        val lines = wrapWords(chunk.map { it.text }, widthLimit, fill)
        val lineHeight = sizePx * 1.22f
        val totalHeight = lineHeight * lines.size
        val baseY = when (position) {
            "top" -> 250f + sizePx
            "middle" -> (1920f - totalHeight) / 2f + sizePx
            else -> 1550f - totalHeight / 2f + sizePx
        }
        val styleColor = customColor ?: when (preset) {
            "NEON" -> 0xFF67F4FF.toInt()
            "MINIMAL" -> 0xFFFFFFFF.toInt()
            "KARAOKE", "POP", "BOLD_PUNCH", "HORMOZI" -> 0xFFFFE45E.toInt()
            else -> 0xFFFFE45E.toInt()
        }
        fill.color = (styleColor and 0x00FFFFFF) or (animationAlpha shl 24)
        val strokeBase = if (preset == "NEON") 0xFF123C49.toInt() else 0xFF000000.toInt()
        stroke.color = (strokeBase and 0x00FFFFFF) or (animationAlpha shl 24)
        stroke.strokeWidth = if (preset == "MINIMAL") 3f else 9f
        fill.setShadowLayer(if (preset == "NEON") 18f else 5f, 0f, 2f, styleColor)
        backdrop.alpha = animationAlpha
        val allText = chunk.joinToString(" ") { it.text }.trim()
        val estimatedWidth = fill.measureText(allText).coerceAtMost(widthLimit)
        val card = RectF(108f, baseY - sizePx * 0.95f, 972f, baseY + totalHeight - lineHeight * 0.2f)
        if (preset == "NEON" || preset == "BOLD_PUNCH" || preset == "HORMOZI") canvas.drawRoundRect(card, 22f, 22f, backdrop)

        // Render lines; active word gets an accent capsule and white/yellow emphasis.
        var wordCursor = 0
        lines.forEachIndexed { lineIndex, lineWords ->
            val lineText = lineWords.joinToString(" ")
            val y = baseY + lineIndex * lineHeight
            val lineWidth = fill.measureText(lineText)
            var x = 540f - lineWidth / 2f
            lineWords.forEach { wordText ->
                val wordIndex = wordCursor
                val wordWidth = fill.measureText(wordText)
                if (wordIndex == activeLocal && preset in setOf("KARAOKE", "POP", "BOLD_PUNCH", "HORMOZI")) {
                    val capsule = RectF(x - 7f, y - sizePx * 0.82f, x + wordWidth + 7f, y + sizePx * 0.18f)
                    val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = (0xCCFFB300.toInt() and 0x00FFFFFF) or ((animationAlpha * 0.8f).toInt() shl 24) }
                    canvas.drawRoundRect(capsule, 12f, 12f, highlightPaint)
                }
                val centerX = x + wordWidth / 2f
                canvas.drawText(wordText, centerX, y, stroke)
                val wordPaint = Paint(fill).apply {
                    color = if (wordIndex == activeLocal && preset in setOf("KARAOKE", "POP", "BOLD_PUNCH", "HORMOZI")) 0xFFFFFFFF.toInt() else styleColor
                    alpha = animationAlpha
                    if (preset == "MINIMAL") setShadowLayer(2f, 0f, 1f, 0xAA000000.toInt())
                }
                canvas.drawText(wordText, centerX, y, wordPaint)
                x += wordWidth + fill.measureText(" ")
                wordCursor++
            }
        }
        canvas.restore()
    }

    private fun wrapWords(input: List<String>, maxWidth: Float, paint: Paint): List<List<String>> {
        val lines = mutableListOf<MutableList<String>>()
        var current = mutableListOf<String>()
        var currentWidth = 0f
        input.forEach { word ->
            val wordWidth = paint.measureText(word) + if (current.isEmpty()) 0f else paint.measureText(" ")
            if (current.isNotEmpty() && currentWidth + wordWidth > maxWidth && lines.size < 1) {
                lines += current
                current = mutableListOf()
                currentWidth = 0f
            }
            current += word
            currentWidth += paint.measureText(word) + if (current.size > 1) paint.measureText(" ") else 0f
        }
        if (current.isNotEmpty()) lines += current
        return lines.take(2)
    }

    companion object {
        private fun parseWords(json: String): List<Word> = runCatching {
            val array = JSONObject(json).optJSONArray("words") ?: JSONArray()
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                val text = obj.optString("text").trim()
                val start = (obj.optDouble("start", 0.0) * 1000).toLong()
                val end = (obj.optDouble("end", 0.0) * 1000).toLong()
                if (text.isNotEmpty() && end >= start) Word(text, start, end) else null
            }
        }.getOrDefault(emptyList())
    }
}
