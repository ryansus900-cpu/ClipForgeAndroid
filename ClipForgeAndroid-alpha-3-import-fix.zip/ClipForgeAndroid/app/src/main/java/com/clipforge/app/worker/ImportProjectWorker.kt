package com.clipforge.app.worker

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import androidx.room.Room
import com.clipforge.app.data.ClipForgeDatabase
import com.clipforge.app.data.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Imports a video into the local project catalog. Media is inspected through a URI, never loaded into RAM. */
class ImportProjectWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val rawUri = inputData.getString(KEY_URI) ?: return@withContext fail("Missing video URI")
        val uri = runCatching { Uri.parse(rawUri) }.getOrNull() ?: return@withContext fail("Invalid URI")
        if (rawUri.isBlank()) return@withContext fail("Blank URI")

        var durationMs = 0L
        var width = 0
        var height = 0

        // Prefer FileDescriptor — more reliable for content:// and file:// on modern Android
        val retriever = MediaMetadataRetriever()
        try {
            val opened = runCatching {
                applicationContext.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    retriever.setDataSource(pfd.fileDescriptor)
                    true
                } ?: false
            }.getOrDefault(false)

            if (!opened) {
                retriever.setDataSource(applicationContext, uri)
            }

            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        } catch (e: Exception) {
            // Still allow import even if metadata fails — user can still transcribe
            durationMs = 0L
            width = 0
            height = 0
        } finally {
            runCatching { retriever.release() }
        }

        val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(
                ClipForgeDatabase.MIGRATION_1_2,
                ClipForgeDatabase.MIGRATION_2_3,
                ClipForgeDatabase.MIGRATION_3_4,
                ClipForgeDatabase.MIGRATION_4_5,
                ClipForgeDatabase.MIGRATION_5_6,
                ClipForgeDatabase.MIGRATION_6_7
            )
            .build()

        try {
            // Avoid duplicate projects for the same URI
            val existing = db.projectDao().findByUri(rawUri)
            if (existing != null) {
                return@withContext Result.success(
                    workDataOf(KEY_RESULT to "already_imported", KEY_PROJECT_ID to existing.id)
                )
            }

            val name = inputData.getString(KEY_NAME)?.takeIf { it.isNotBlank() } ?: "Video project"
            val id = db.projectDao().insert(
                ProjectEntity(
                    name = name,
                    sourceUri = rawUri,
                    sourceType = if (rawUri.startsWith("http")) "url" else "file",
                    status = "imported",
                    durationMs = durationMs,
                    videoWidth = width,
                    videoHeight = height
                )
            )
            Result.success(workDataOf(KEY_RESULT to "imported", KEY_PROJECT_ID to id))
        } catch (e: Exception) {
            fail("Database error: ${e.message?.take(120)}")
        } finally {
            db.close()
        }
    }

    private fun fail(message: String): Result =
        Result.failure(workDataOf(KEY_ERROR to message))

    companion object {
        const val KEY_URI = "video_uri"
        const val KEY_NAME = "display_name"
        const val KEY_RESULT = "result"
        const val KEY_PROJECT_ID = "project_id"
        const val KEY_ERROR = "error"
    }
}
