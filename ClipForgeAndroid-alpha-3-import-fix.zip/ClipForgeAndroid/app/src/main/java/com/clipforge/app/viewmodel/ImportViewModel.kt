package com.clipforge.app.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

 data class ImportUiState(
    val videoUri: String? = null,
    val sourceUrl: String = "",
    val rightsConfirmed: Boolean = false,
    val status: String = "Import a video to begin.",
    val busy: Boolean = false,
)

class ImportViewModel : ViewModel() {
    private val _state = MutableStateFlow(ImportUiState())
    val state: StateFlow<ImportUiState> = _state.asStateFlow()

    fun setVideo(uri: String?) = _state.update { it.copy(videoUri = uri, status = if (uri != null) "Video selected. Ready for milestone 1." else it.status) }
    fun setUrl(url: String) = _state.update { it.copy(sourceUrl = url) }
    fun setRights(confirmed: Boolean) = _state.update { it.copy(rightsConfirmed = confirmed) }

    fun startTranscriptionPrep() {
        val s = _state.value
        when {
            !s.rightsConfirmed -> _state.update { it.copy(status = "Please confirm you own the video or have permission to use it.") }
            s.videoUri.isNullOrBlank() && s.sourceUrl.isBlank() -> _state.update { it.copy(status = "Choose a video or enter a source link first.") }
            s.sourceUrl.contains("youtube.com", true) || s.sourceUrl.contains("youtu.be", true) -> _state.update { it.copy(status = "YouTube link noted. Direct downloading is not included; use a file you have rights to and import it from your device.") }
            else -> _state.update { it.copy(status = "Import milestone ready. Transcription engine is the next integration.") }
        }
    }
}
