package com.clipforge.app.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ImportUiState(
    val videoUri: String? = null,
    val sourceUrl: String = "",
    val rightsConfirmed: Boolean = false,
    val status: String = "Import a video or paste a YouTube / TikTok / Instagram link.",
    val busy: Boolean = false,
    val lastError: String? = null,
)

class ImportViewModel : ViewModel() {
    private val _state = MutableStateFlow(ImportUiState())
    val state: StateFlow<ImportUiState> = _state.asStateFlow()

    fun setVideo(uri: String?) = _state.update {
        it.copy(
            videoUri = uri,
            status = if (uri != null) "Video ready. Confirm rights to continue." else it.status,
            lastError = null,
        )
    }

    fun setUrl(url: String) = _state.update { it.copy(sourceUrl = url, lastError = null) }

    fun setRights(confirmed: Boolean) = _state.update { it.copy(rightsConfirmed = confirmed) }

    fun setBusy(busy: Boolean) = _state.update { it.copy(busy = busy) }

    fun setStatus(status: String) = _state.update { it.copy(status = status) }

    fun setError(message: String) = _state.update {
        it.copy(busy = false, lastError = message, status = message)
    }

    fun clearError() = _state.update { it.copy(lastError = null) }

    fun canStartImport(): Boolean {
        val s = _state.value
        return s.rightsConfirmed && (!s.videoUri.isNullOrBlank() || s.sourceUrl.isNotBlank())
    }
}
