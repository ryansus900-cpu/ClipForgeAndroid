package com.clipforge.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sends the saved timestamped transcript to ClipForge's backend clip-discovery endpoint. */
class ClipAnalysisProvider(private val baseUrl: String) {
    suspend fun analyze(transcriptJson: String, language: String, prompt: String = "", count: Int = 8): JSONObject = withContext(Dispatchers.IO) {
        require(baseUrl.isNotBlank()) { "ClipForge backend URL is not configured." }
        require(baseUrl.startsWith("https://") || baseUrl.startsWith("http://10.0.2.2") || baseUrl.startsWith("http://localhost")) {
            "Backend must use HTTPS (HTTP is allowed only for local emulator testing)."
        }
        val transcript = JSONObject(transcriptJson)
        val words = transcript.optJSONArray("words") ?: JSONArray()
        val payload = JSONObject().put("words", words).put("detected_language", language)
            .put("clip_count", count).put("prompt", prompt)
        val connection = (URL(baseUrl.trimEnd('/') + "/api/clips/analyze").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20_000; readTimeout = 60_000; doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) throw IllegalStateException("Clip analysis failed (HTTP $status): ${body.take(240)}")
            JSONObject(body)
        } finally { connection.disconnect() }
    }
}
