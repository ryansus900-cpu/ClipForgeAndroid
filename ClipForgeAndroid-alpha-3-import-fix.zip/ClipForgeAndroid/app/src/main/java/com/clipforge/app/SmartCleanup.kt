package com.clipforge.app

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

private data class CleanupCut(val start: Double, val end: Double, val reason: String, val label: String)

private fun buildCleanupSuggestions(transcriptJson: String): List<CleanupCut> {
    val words = runCatching { JSONObject(transcriptJson).optJSONArray("words") ?: JSONArray() }.getOrNull() ?: return emptyList()
    val fillerTokens = setOf("um", "umm", "uh", "uhh", "erm", "hmm", "hm", "matlab", "achha", "acha", "haan", "han", "arey", "dekho", "yaar", "basically")
    val suggestions = mutableListOf<CleanupCut>()
    var previousEnd: Double? = null
    for (i in 0 until words.length()) {
        val word = words.optJSONObject(i) ?: continue
        val text = word.optString("text").trim()
        val start = word.optDouble("start", -1.0)
        val end = word.optDouble("end", -1.0)
        if (start < 0 || end <= start || text.isBlank()) continue
        val normalized = text.lowercase().trim(',', '.', '!', '?', ':', ';')
        if (normalized in fillerTokens) {
            suggestions += CleanupCut((start - .08).coerceAtLeast(0.0), end + .08, "filler", "Possible filler: $text")
        }
        val prev = previousEnd
        if (prev != null) {
            val gap = start - prev
            if (gap >= .65) {
                val cutStart = prev + .08
                val cutEnd = (start - .08).coerceAtLeast(cutStart)
                if (cutEnd - cutStart >= .25) suggestions += CleanupCut(cutStart, cutEnd, "pause", "Pause · ${"%.1f".format(gap)} sec")
            }
        }
        previousEnd = end
    }
    return suggestions.sortedBy { it.start }
}

@Composable
fun SmartCleanupScreen(transcriptJson: String, savedSettingsJson: String, onSave: (String) -> Unit, onClose: () -> Unit) {
    val cuts = remember(transcriptJson) { buildCleanupSuggestions(transcriptJson) }
    val saved = remember(savedSettingsJson) { runCatching { JSONObject(savedSettingsJson).optJSONArray("cleanupCuts") }.getOrNull() }
    val initialIds = remember(cuts, saved) {
        if (saved == null) cuts.indices.toSet() else (0 until saved.length()).mapNotNull { saved.optInt(it, -1).takeIf { id -> id >= 0 } }.toSet()
    }
    var selected by remember(cuts) { mutableStateOf(initialIds) }
    var savedMessage by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SMART CLEANUP", color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Close") }
        }
        Text("Review possible filler words and pauses. Suggestions are estimates; select only the cuts you want to keep.", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodySmall)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF191723))) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text("${cuts.size} suggested edits", color = Color(0xFF9B72F2), style = MaterialTheme.typography.titleMedium)
                Text("${selected.size} selected · Nothing is removed automatically", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodySmall)
            }
        }
        if (cuts.isEmpty()) Text("No filler words or timestamp gaps were found in the available transcript. Try transcribing first.", color = Color.White)
        cuts.forEachIndexed { index, cut ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF242131))) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = index in selected, onCheckedChange = { checked -> selected = if (checked) selected + index else selected - index })
                    Column(Modifier.weight(1f)) {
                        Text(cut.label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                        Text("${"%.2f".format(cut.start)}s – ${"%.2f".format(cut.end)}s · ${cut.reason}", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        Button(onClick = {
            val root = runCatching { JSONObject(savedSettingsJson) }.getOrElse { JSONObject() }
            val ids = JSONArray()
            selected.sorted().forEach { ids.put(it) }
            val cutArray = JSONArray()
            cuts.forEach { c ->
                cutArray.put(JSONObject().put("start", c.start).put("end", c.end).put("reason", c.reason).put("label", c.label))
            }
            root.put("cleanupCuts", ids).put("cleanupCutDetails", cutArray).put("cleanupVersion", 2)
            onSave(root.toString())
            savedMessage = "Selection saved. Selected cleanup cuts will be applied during export."
        }, modifier = Modifier.fillMaxWidth()) { Text("Save selected suggestions") }
        if (savedMessage.isNotBlank()) Text(savedMessage, color = Color(0xFF8CE6A6), style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Return to project") }
        Text("This version detects fillers from transcript tokens and pauses from word timestamp gaps. It is not a fully automatic audio-quality editor yet.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
    }
}
