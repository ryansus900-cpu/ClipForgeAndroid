package com.clipforge.app.data

import javax.inject.Inject

class ProjectRepository @Inject constructor(private val dao: ProjectDao) {
    val projects = dao.observeProjects()
    suspend fun create(name: String, uri: String, sourceType: String = "file") =
        dao.insert(ProjectEntity(name = name, sourceUri = uri, sourceType = sourceType))
}
