package com.clipforge.app.data

/** Milestone 1 contract. Implement with on-device whisper.cpp or a secured API provider. */
interface TranscriptionProvider {
    suspend fun transcribe(videoUri: String, languageHint: String = "auto"): TranscriptResult
}

data class TranscriptResult(
    val detectedLanguage: String,
    val words: List<TranscriptWord>,
)

data class TranscriptWord(
    val text: String,
    val startSeconds: Double,
    val endSeconds: Double,
)
