package com.clipforge.app.data

import android.content.Context
import android.net.Uri
import com.clipforge.app.BuildConfig
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.pow

data class AudioWaveformData(val durationSeconds: Float, val amplitudes: List<Float>)

/** Fetches real RMS waveform windows from ClipForge's FFmpeg backend. */
class AudioWaveformProvider(private val context: Context) {
    suspend fun load(uri: Uri): AudioWaveformData = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val base = BuildConfig.CLIPFORGE_API_BASE.trim().trimEnd('/')
        require(base.isNotBlank()) { "Set CLIPFORGE_API_BASE to enable waveform analysis." }
        require(base.startsWith("https://") || base.startsWith("http://10.0.2.2") || base.startsWith("http://localhost")) {
            "Waveform API must use HTTPS (localhost is allowed for development)."
        }
        val conn = (URL("$base/api/audio/analyze").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 20_000
            readTimeout = 900_000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=ClipForgeBoundary")
            setChunkedStreamingMode(1024 * 1024)
        }
        try {
            conn.outputStream.use { out ->
                out.write("--ClipForgeBoundary\r\nContent-Disposition: form-data; name=\"video\"; filename=\"source.mp4\"\r\nContent-Type: video/mp4\r\n\r\n".toByteArray())
                context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out, 1024 * 1024) }
                    ?: error("Unable to open video for waveform analysis")
                out.write("\r\n--ClipForgeBoundary\r\nContent-Disposition: form-data; name=\"words_json\"\r\n\r\n[]\r\n--ClipForgeBoundary--\r\n".toByteArray())
            }
            val code = conn.responseCode
            val stream: InputStream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }
            check(code in 200..299) { "Waveform service returned HTTP $code: $body" }
            val response = JSONObject(body)
            val duration = response.optDouble("duration_seconds", 0.0).toFloat()
            val windows = response.optJSONArray("windows") ?: return@withContext AudioWaveformData(duration, emptyList())
            val raw = (0 until windows.length()).map { i ->
                val db = windows.optJSONObject(i)?.optDouble("rms_dbfs", -120.0) ?: -120.0
                (10.0.pow(db / 20.0).toFloat()).coerceIn(0f, 1f)
            }
            // Keep the UI lightweight on long recordings while preserving peak detail per bin.
            val maxBars = 900
            val bins = if (raw.size <= maxBars) raw else List(maxBars) { idx ->
                val from = idx * raw.size / maxBars
                val to = ((idx + 1) * raw.size / maxBars).coerceAtLeast(from + 1).coerceAtMost(raw.size)
                raw.subList(from, to).maxOrNull() ?: 0f
            }
            AudioWaveformData(duration, bins)
        } finally {
            conn.disconnect()
        }
    }
}
