package com.clipforge.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sourceUri: String,
    val sourceType: String = "file",
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val status: String = "imported",
    val durationMs: Long = 0,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,
    val detectedLanguage: String = "",
    val transcriptJson: String = "",
    val transcriptionStatus: String = "not_started",
    val clipCandidatesJson: String = "",
    val clipAnalysisStatus: String = "not_started",
    val editSettingsJson: String = "",
    val subtitleSettingsJson: String = "",
    val socialMetadataJson: String = ""
)
