package com.clipforge.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import org.json.JSONObject
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private data class TitlePack(val titles: List<String>, val description: String, val hashtags: String)

/** Offline, template-based title ideas. No claim of generative AI; backend generation can replace this later. */
private fun createTitlePack(clipText: String, category: String, language: String, customPrompt: String): TitlePack {
    val clean = clipText.trim().replace(Regex("\\s+"), " ").take(240)
    val seed = clean.trimEnd('.', '!', '?', '…')
    val prompt = customPrompt.trim()
    val english = when (language) {
        "Hindi" -> listOf("ये बात आपको जरूर जाननी चाहिए", "सिर्फ एक गलती सब बदल सकती है", "इसका जवाब आपको हैरान करेगा", "आखिर ऐसा क्यों होता है?", "याद रखिए ये जरूरी बात")
        "Hinglish" -> listOf("Ye baat aapko zaroor jaanani chahiye", "Ek mistake sab kuch badal sakti hai", "Iska answer aapko surprise karega", "Aakhir aisa kyun hota hai?", "Ye important baat yaad rakhna")
        else -> listOf("You Need to Hear This", "One Mistake Can Change Everything", "The Answer Might Surprise You", "Why Does This Actually Happen?", "Remember This Important Lesson")
    }
    val base = if (seed.isBlank()) listOf("A Moment Worth Sharing", "The Key Takeaway", "Watch This Short Insight") else listOf(seed, "${seed.take(78)} — The Key Takeaway", "${seed.take(72)}: What It Means", "${seed.take(68)} (Short Explained)", "${seed.take(65)} — Don't Miss This")
    val titles = (base + english).map { if (prompt.isBlank()) it else "$it" }.distinct().take(10)
    val shortDesc = if (seed.isBlank()) "A short clip worth watching. Follow for more." else "${seed.take(180)}${if (seed.length > 180) "…" else ""}\n\nWatch, share, and follow for more ${category.lowercase()} clips."
    val tags = buildList {
        add("#Shorts"); add("#Reels"); add("#ClipForge")
        val normalized = category.lowercase()
        when {
            normalized.contains("fun") -> addAll(listOf("#FunnyMoments", "#Comedy"))
            normalized.contains("motivat") -> addAll(listOf("#Motivation", "#Mindset"))
            normalized.contains("money") || normalized.contains("business") -> addAll(listOf("#Money", "#Business"))
            normalized.contains("emotion") -> addAll(listOf("#Emotional", "#Life"))
            else -> addAll(listOf("#Highlights", "#ViralClips"))
        }
        if (language != "English") add("#Hindi")
    }.distinct().joinToString(" ")
    return TitlePack(titles, shortDesc, tags)
}

@Composable
fun TitleStudio(
    clipText: String,
    category: String,
    detectedLanguage: String,
    savedMetadataJson: String,
    onSave: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val rawSaved = remember(savedMetadataJson) { runCatching { JSONObject(savedMetadataJson) }.getOrElse { JSONObject() } }
    val saved = remember(rawSaved, clipText) { if (rawSaved.optString("clip_text") == clipText) rawSaved else JSONObject() }
    var language by remember { mutableStateOf(saved.optString("language", when { detectedLanguage.contains("hi", true) -> "Hindi"; detectedLanguage.contains("hing", true) -> "Hinglish"; else -> "English" })) }
    var customPrompt by remember { mutableStateOf(saved.optString("prompt", "")) }
    var selectedTitle by remember { mutableStateOf(saved.optString("selected_title", "")) }
    var editableDescription by remember { mutableStateOf(saved.optString("description", "")) }
    var editableHashtags by remember { mutableStateOf(saved.optString("hashtags", "")) }
    val pack = remember(clipText, category, language, customPrompt) { createTitlePack(clipText, category, language, customPrompt) }
    LaunchedEffect(pack) {
        if (selectedTitle.isBlank() || selectedTitle !in pack.titles) selectedTitle = pack.titles.firstOrNull().orEmpty()
        if (editableDescription.isBlank()) editableDescription = pack.description
        if (editableHashtags.isBlank()) editableHashtags = pack.hashtags
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Title & Packaging Studio", style = MaterialTheme.typography.titleLarge, color = Color.White)
            TextButton(onClick = onClose) { Text("Close") }
        }
        Text("Ideas are generated locally with templates in this alpha. They are not AI-generated yet.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
        Text("Clip context · ${category.ifBlank { "Highlight" }}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF201D2C))) {
            Text(clipText.ifBlank { "No clip transcript selected" }, Modifier.padding(12.dp), color = Color.White, style = MaterialTheme.typography.bodySmall)
        }
        Text("Title language", style = MaterialTheme.typography.titleSmall, color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("English", "Hindi", "Hinglish").forEach { lang ->
                FilterChip(selected = language == lang, onClick = { language = lang }, label = { Text(lang) })
            }
        }
        OutlinedTextField(value = customPrompt, onValueChange = { customPrompt = it }, label = { Text("Direction (optional)") }, placeholder = { Text("e.g. curious, not clickbait; focus on the lesson") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Text("Title ideas", style = MaterialTheme.typography.titleSmall, color = Color.White)
        pack.titles.forEach { title ->
            Card(onClick = { selectedTitle = title }, colors = CardDefaults.cardColors(containerColor = if (selectedTitle == title) Color(0xFF3A2D56) else Color(0xFF201D2C)), shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(title, color = Color.White, modifier = Modifier.weight(1f))
                    RadioButton(selected = selectedTitle == title, onClick = { selectedTitle = title })
                }
            }
        }
        OutlinedTextField(value = selectedTitle, onValueChange = { selectedTitle = it }, label = { Text("Selected title (editable)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        OutlinedTextField(value = editableDescription, onValueChange = { editableDescription = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        OutlinedTextField(value = editableHashtags, onValueChange = { editableHashtags = it }, label = { Text("Hashtags") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { copyText(context, "$selectedTitle\n\n$editableDescription\n\n$editableHashtags") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text("Copy package") }
            Button(onClick = {
                val metadata = JSONObject().put("language", language).put("prompt", customPrompt).put("selected_title", selectedTitle).put("description", editableDescription).put("hashtags", editableHashtags).put("category", category).put("clip_text", clipText).toString()
                onSave(metadata)
            }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text("Save") }
        }
    }
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("ClipForge social package", text))
    android.widget.Toast.makeText(context, "Copied title, description and hashtags", android.widget.Toast.LENGTH_SHORT).show()
}
