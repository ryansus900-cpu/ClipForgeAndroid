package com.clipforge.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Device-local reusable caption style presets shared across projects. */
object CaptionBrandKitStore {
    private const val PREFS = "clipforge_caption_brand_kit"
    private const val KEY_PRESETS = "presets"

    fun load(context: Context): List<JSONObject> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PRESETS, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { array.optJSONObject(it)?.let { JSONObject(it.toString()) } }
    }.getOrDefault(emptyList())

    fun save(context: Context, name: String, style: JSONObject) {
        val cleaned = name.trim().take(32)
        if (cleaned.isEmpty()) return
        val presets = load(context).filterNot { it.optString("name").equals(cleaned, ignoreCase = true) }.toMutableList()
        presets.add(JSONObject().put("name", cleaned).put("style", JSONObject(style.toString())))
        val json = JSONArray()
        presets.takeLast(30).forEach { json.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PRESETS, json.toString()).apply()
    }

    fun delete(context: Context, name: String) {
        val json = JSONArray()
        load(context).filterNot { it.optString("name") == name }.forEach { json.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_PRESETS, json.toString()).apply()
    }
}
