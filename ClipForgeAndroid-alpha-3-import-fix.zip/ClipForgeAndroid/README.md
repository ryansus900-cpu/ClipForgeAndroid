# ClipForge Android (alpha scaffold)

Native Android app foundation for Hindi, English and Hinglish short-form creators. Kotlin, Jetpack Compose, Material 3, MVVM-ready, Hilt, Room, WorkManager and Media3 dependencies.

## Current status

**Alpha 0.8: Import + cloud transcription + transcript clip discovery + subtitle studio + edit/export source + title packaging studio.** Includes Compose import, gallery/share, rights confirmation, WorkManager import inspection, Room project storage, a streaming multipart upload client, a transcription worker, and an editable backend URL configuration. The app can queue transcription and persist detected language plus word timestamps, but it requires the developer backend to be running and configured. This remains an unbuilt/unverified source project, not a production APK.

## Requirements / target

- `minSdk 26`, `arm64-v8a` only for release.
- Release minification (`R8`) and resource shrinking enabled.
- No bundled AI models. Cloud STT is intended default; optional whisper.cpp tiny/base model downloads are planned, with progress/resume, not included in this scaffold.
- Videos should be handled via content URIs/file descriptors/streaming; do not read full video into RAM.
- Target release APK: <= 67 MB. Actual size must be measured after build; no size claim is made before an APK exists.

## Setup

1. Install Android Studio (current stable), Android SDK 35, and JDK 17.
2. Open this folder in Android Studio and allow Gradle sync.
3. This repository currently has no Gradle wrapper. In Android Studio use the installed Gradle to sync/build, or add a wrapper from a compatible Gradle 8.9 installation (`gradle wrapper --gradle-version 8.9`). To configure the transcription backend, add `CLIPFORGE_API_BASE=https://your-backend.example` to Gradle properties (local testing on the Android emulator may use `http://10.0.2.2:8000`), then rebuild. A backend starter is in `backend/`; it requires Python, FFmpeg, and server-side `OPENAI_API_KEY`. Never put the provider key in the app.
4. Build release: `gradle :app:assembleRelease` (or `./gradlew :app:assembleRelease` once wrapper is added).
5. Check size: `python scripts/apk_size_report.py app/build/outputs/apk/release/app-release.apk`.

## Project layout

```text
ClipForgeAndroid/
  app/
    src/main/AndroidManifest.xml
    src/main/java/com/clipforge/app/
      ClipForgeApplication.kt
      MainActivity.kt
      data/ProjectEntity.kt
      data/ProjectDao.kt
      data/ClipForgeDatabase.kt
      data/ProjectRepository.kt
      di/AppModule.kt
      worker/ImportProjectWorker.kt
    build.gradle.kts
    proguard-rules.pro
  scripts/apk_size_report.py
```

## APK size budget checklist (estimate only, not measured)

Only one app module exists in this scaffold; dependencies are all in `:app`. Size is affected by AGP/Kotlin/Compose versions, ABI, resource optimization, and transitive libraries. Measure the final release APK and inspect `Analyze APK` in Android Studio before release.

| Component / optimization | Budget guidance | Verification |
|---|---:|---|
| Kotlin/Compose UI + app code | 4–10 MiB | Analyze APK `classes.dex` |
| Compose/Material/AndroidX | 8–15 MiB | Analyze APK, dependency report |
| Media3 playback/transformer | 8–18 MiB | Inspect native + dex entries |
| Room, WorkManager, Hilt, coroutines | 3–7 MiB | APK analyzer |
| Native codecs/runtime and other dependencies | 8–20 MiB | APK analyzer; ABI-only filtering |
| Resources, icons, assets | 1–3 MiB | APK analyzer |
| **Target** | **<= 67 MiB** | Release APK size script |

These component ranges are planning estimates and overlap/variance means they must not be summed as a guaranteed result. If the measured APK exceeds target, remove unused Media3 modules, avoid large icon/font packs, verify arm64-only packaging, and inspect native libraries before choosing replacements.

## Optimization checklist

- [x] `arm64-v8a` ABI filter configured
- [x] Release `isMinifyEnabled = true`
- [x] Release `isShrinkResources = true`
- [x] Vector icons via Compose Material icons (tree-shaking may reduce used symbols)
- [ ] Font assets limited to 4–5 subsetted files (none bundled yet)
- [ ] Convert raster assets to WebP as they are added (none bundled yet)
- [x] AI models are not packaged in APK
- [ ] Build and measure real APK <= 67 MB
- [ ] Generate Gradle dependency and APK Analyzer report

## Milestones

1. **Import + transcription:** import/picker/share/rights UX and metadata inspection; cloud STT backend integration returns word timestamps and language; optional downloadable offline model with resumable progress is still planned.
2. **Clip scoring (alpha implementation):** transcript-only heuristic analysis endpoint; hook/completeness/emotion-word/duration estimates; categories and prompt bias; candidate cards with timestamps, text, scores and reasons. Audio energy, facial cues, true pace, and an LLM semantic review are not yet analyzed.
3. **Subtitles:** 20+ styles, word timing, editable transcript, Devanagari/English/Roman Hinglish and translations, live preview.
4. **Titles (0.8 source milestone):** template-based title suggestions, editable description, category-based hashtags, language selection, copy package, save metadata in Room. Not an AI title API yet.
5. **Export:** Media3/FFmpeg evaluation, 9:16 crop/reframe, 1080p H.264/H.265, 30/60 fps, queue/progress notifications and sharing.

## Transcription backend response contract

The Android client expects `POST /api/transcribe` multipart fields `video` (video file) and `language` (`auto` or language code). JSON response shape:

```json
{
  "detected_language": "english",
  "words": [{ "text": "Hello", "start": 0.0, "end": 0.45 }]
}
```

The backend also exposes `POST /api/clips/analyze`, which accepts saved transcript words and returns suggested segments with heuristic scores, categories, timestamps, score dimensions, and selection reasons. The Android project adds a clip-analysis WorkManager job and persists results in Room (schema v4). This is transcript-only discovery, not a guarantee of virality or full audio/visual AI.

The included backend sample is a developer starter only. It uses FFmpeg and a cloud transcription API; costs may apply. Its timestamp provider currently uses `whisper-1`, which OpenAI docs mark as deprecated for this specialized timestamp workflow, with shutdown scheduled for 26 February 2027. Review and replace this provider before production.

## Security and content rights

Link processing must be restricted to content the user owns or is authorized to process. Require rights confirmation before remote or local processing. Do not implement bypasses for platform access controls or DRM. Keep API credentials on a backend; never hardcode secret keys in the Android client.

## Milestone 1 progress update

The import pipeline now includes:
- Device video selection through Android's document picker.
- Best-effort persistable read permission for selected content URIs.
- Rights-confirmation gate in the import screen.
- WorkManager background import job.
- MediaMetadataRetriever inspection (duration, dimensions) without loading the video into RAM.
- Local Room project record with source URI and metadata.

Transcription integration added in alpha 0.3: app streams the selected video to configured backend, WorkManager performs the job with a foreground notification, backend extracts and segments audio, Whisper word timestamps are returned and stored in Room, and the UI shows detected language/transcript. This feature cannot run without the backend URL, backend deployment, and API account. No speaker diarization or offline Whisper is included. Source remains uncompiled and untested in this environment.


## Milestone 2 progress update — transcript clip discovery (alpha 0.4)

- Added `backend/clip_analysis.py` for sentence/pause grouping and 8–75 second candidate-window generation.
- Candidate scoring estimates hook, emotion-word cues, thought completeness, duration suitability, and an unmeasured pace placeholder.
- Categories include funny, motivational, money/business, emotional, and informative. Prompt keywords provide soft ranking preference.
- Backend route `POST /api/clips/analyze` accepts transcript words/language/count/prompt and returns candidate clips.
- Android adds clip-analysis API provider + WorkManager worker, Room schema v4 migration, and suggested-clip cards displaying score, category, transcript, and time range.
- Added three Python unit tests; they pass. Android Gradle compilation remains unavailable/unverified.
- The current scoring is heuristic and text-only. The emotion and pace dimensions are not reliable audio analysis yet; use them as provisional ranking hints.


## Milestone 3 — Subtitle Studio (0.5 alpha)

- Added a Compose Subtitle Studio screen for imported/transcribed projects.
- Caption style preview presets: Bold Yellow, Minimal, Karaoke, Neon, Pop-in, and Bold Punch.
- Caption font-size slider and Top/Middle/Bottom placement preview.
- Editable transcript text and save-to-project flow.
- When word count is unchanged, existing word timestamps are preserved. When word count changes, timing is evenly estimated over the original transcript duration (not speech-aligned; review needed).
- Caption styling is currently preview-only; burned-in captions and subtitle export are not implemented.
- Android build remains unverified in this environment (no Android SDK/Gradle toolchain).

## Milestone 4 — Clip Editor (alpha source)

The app has a Clip Editor screen reachable from each suggested clip. It includes a Media3 playback preview, segment start/end sliders constrained to the candidate range, 9:16 crop vs source-fit framing, and zoom settings. Edit recipes are saved to Room using schema migration 4→5. Export was added in milestone 5.


## Milestone 5: MP4 export alpha (0.6.0)

Added a Media3 Transformer export worker connected to the Clip Editor's **Export MP4** button. It exports the selected trim range, uses H.264/AAC output, applies a 1080x1920 crop-to-fill vertical presentation when vertical framing is selected, applies the saved zoom setting, and reports background progress through a foreground notification. Android 10+ writes finished MP4s to `Movies/ClipForge` using MediaStore. Android 8–9 stores exports in app-specific Movies storage (gallery visibility/share handling remains to be improved for legacy versions).

**Still not implemented:** burned-in subtitles, face-tracking crop, selectable 30/60 fps, export quality controls, robust queue UI/cancel/retry, and real-device export validation. Android compilation and export tests have not been run in this environment.

## Milestone 4: subtitle burn-in (0.7 alpha source update)

- Subtitle Studio now saves style preset, size, and caption position to Room in a version-6 migration.
- Export can burn captions into MP4 when a transcript is saved and the editor's caption checkbox is enabled.
- Media3 CanvasOverlay renders time-synchronized word groups (up to five words) and active-word emphasis for Karaoke/Pop/Bold Punch styles, with Hindi/English text drawing via Android's text rendering.
- Caption preset, font size, and Top/Middle/Bottom position settings are used by the export overlay.
- Export worker looks up the saved project by source URI; transcript and style JSON are not put into WorkManager's small input Data payload.

**Not yet device-verified:** Media3 effect timing with clipped timelines, caption layout on different videos, Devanagari/Hinglish font coverage, export performance and actual burned subtitle output. Android build environment is still needed to compile and run tests.


## Milestone 6 — Title & Packaging Studio (0.8 alpha source update)

- Added a native Compose Title & Packaging Studio opened from the project transcript or an individual suggested clip.
- Generates local template title ideas, with English/Hindi/Hinglish language options. This is template/heuristic output, not AI generation; a backend LLM title endpoint is a later enhancement.
- Editable title selection, description and hashtags; copy all selected packaging text to clipboard.
- Saves metadata JSON to the project database with Room schema migration 6→7.
- Optional direction prompt is saved with the package for future provider integration; currently it does not change generation beyond being recorded.
- Updated app version to 0.8.0-alpha (versionCode 8).

**Verification limitations:** Python backend tests are independent of this Android UI and are run separately. Android compilation, Room migration on device, clipboard, and UI testing have not been verified because this environment has no Android SDK/Gradle build toolchain.

## Milestone: Audio Intelligence API (development implementation)
- New backend `POST /api/audio/analyze` streams FFmpeg-decoded PCM into a windowed RMS/peak analyzer instead of buffering the full audio track.
- Reports half-second energy windows, approximate silence intervals (RMS threshold), silence ratio, peak/average RMS, and large energy-change points.
- Optional transcript word list returns a **word-count-based pace estimate**, not true acoustic speaking rate.
- It does not detect laughter, speaker identities, emotion, or sound-event categories yet. Those require models.
- Added unit tests for silence, loud signal, empty stream, and pace estimate.
- Android client/UI integration remains a later task; backend endpoint is not yet wired into the Android app.


## Milestone: audio-aware clip ranking (backend)
- Added `POST /api/clips/analyze`, matching the Android JSON client payload (`words`, `detected_language`, `clip_count`, `prompt`).
- Optional `audio_features` windows adjust transcript candidate scores by 15% using audible-window continuity and silence fraction.
- With no audio features, the endpoint keeps transcript-only scoring. The Android client is not yet sending audio features, so default app behavior remains transcript-only until the client integration milestone.
- These audio signals do not classify laughter/emotion or guarantee virality.

## Milestone: Speech cleanup recommendations (backend)
- New `POST /api/audio/cleanup/analyze` endpoint combines FFmpeg energy/silence analysis with transcript timing.
- Detects likely English/Hindi/Hinglish filler tokens using a lexical list (may misclassify meaningful words such as “like”, “actually”, or “तो”).
- Estimates transcript pace overall and in overlapping 15-second windows with 5-second stride, based on timestamped word counts. This is not acoustic speech-rate detection.
- Returns long-silence and filler cut suggestions. Suggestions are explicitly review-only and do not modify/render the video.
- Android UI/client connection and automatic cut application remain not implemented.


## Milestone 1.2 Alpha — Smart Cleanup Review UI (source implementation)

- Added an Android Compose Smart Cleanup review screen, reachable from the project transcript panel.
- Locally flags common English/Hinglish filler tokens in timed transcripts and timestamp gaps of at least 0.65 seconds as pause suggestions.
- Each suggested edit is selectable; no suggestion is applied automatically.
- Saves the selected cut details in the existing edit-settings JSON without replacing trim/framing values.
- UI currently uses transcript word timestamps; it does not yet call the backend acoustic silence endpoint, render cuts, or perform destructive cleanup. Export integration remains a later milestone.
- Version metadata updated to 0.9.0-alpha / code 9.
- Backend regression tests: 12 passed; Python syntax checks passed. Android compilation/device testing not available in this environment.


## Milestone 1.2 Alpha — Smart Cleanup Review UI (source implementation)

- Added an Android Compose Smart Cleanup review screen, reachable from the project transcript panel.
- Locally flags common English/Hinglish filler tokens in timed transcripts and timestamp gaps of at least 0.65 seconds as pause suggestions.
- Each suggested edit is selectable; no suggestion is applied automatically.
- Saves the selected cut details in the existing edit-settings JSON without replacing trim/framing values.
- UI currently uses transcript word timestamps; it does not yet call the backend acoustic silence endpoint, render cuts, or perform destructive cleanup. Export integration remains a later milestone.
- Version metadata updated to 0.9.0-alpha / code 9.
- Backend regression tests: 12 passed; Python syntax checks passed. Android compilation/device testing not available in this environment.

## ClipForge 1.3 Alpha — Timeline Cut Export (source milestone)
- Smart Cleanup now persists **all** detected cut details plus the selected indices, so selections map correctly to cut time ranges.
- Export worker intersects selected cleanup ranges with the user's trim range, merges overlapping cuts, and builds kept segments.
- Media3 `Composition` / `EditedMediaItemSequence` exports the kept segments sequentially to remove approved pauses/filler intervals.
- Captions, vertical crop and zoom effects are configured per kept segment. Caption timing uses the original timeline segment start.
- No cleanup edits are applied unless selected and saved. Empty/invalid cut selections keep the full trimmed interval.
- Android compilation and device export are not verified in this environment; this is a source milestone only.


## 1.4 Alpha — Transcript timeline preview

- Clip Editor now visualizes transcript word timing across the selected trim range.
- Approved cleanup ranges are overlaid as red bands; word timing markers appear purple; playhead appears white.
- Timeline slider scrubs the preview player. Tapping transcript chips jumps to the word's timestamp.
- The timeline is a transcript-timing visualization, not a measured audio waveform. Playback-position synchronization during continuous play and true waveform extraction are not implemented.
- Android build/device verification is not available in this environment.


## Milestone 1.5 Alpha — Real waveform and direct timeline gestures (source update)

- Android `AudioWaveformProvider` uploads the source video to the existing `/api/audio/analyze` endpoint using chunked multipart streaming (does not load the whole source video into memory).
- Converts backend RMS dBFS windows to display amplitudes; aggregates to at most 900 display bins.
- Clip editor displays real audio RMS waveform bars when backend is configured; gracefully falls back when unavailable.
- Timeline drag gestures: center scrubs playback; left/right edge zones adjust trim start/end. Yellow edge markers identify trim handles.
- API URL must be HTTPS, except emulator localhost development endpoints.
- Android build/device behavior remains unverified; waveform needs a configured reachable backend.

## 1.6 Alpha — synchronized playback and timeline state

- Preview playhead is synchronized from ExoPlayer playback position while playing and paused.
- Playback is constrained to the selected trim window and stops at its end boundary.
- Scrubbing and transcript-word jumps pause playback and seek the preview to the selected time.
- Changing trim handles pauses preview and clamps the playhead into the edited range.
- Saved editor settings now include a `playhead` value (settings schema version 3) alongside trim, zoom, and framing; cleanup cut metadata remains preserved by the project save callback.
- The editor restores the saved playhead, clamped to the current candidate trim bounds.

Validation: backend tests pass; Kotlin source syntax check only. Android Gradle build/device playback remains unverified in this environment.

## 1.7 Alpha — Smart Cleanup playback integration

- Clip Editor playback now skips saved, approved cleanup ranges while playing, using original-source timestamps so the timeline playhead remains aligned to the source video.
- Starting preview from a position inside an approved cut jumps to the end of that cut before playback begins.
- Editor status text indicates whether cleanup cuts are saved and selected, and whether cleaned preview is active.
- The existing export worker already intersects saved cleanup cuts with the trim range, merges overlaps, and exports kept segments; this milestone aligns interactive preview behavior with that export logic.
- Unsaved cleanup selections are not applied to preview/export until saved through Smart Cleanup.
- Version metadata updated to 1.7.0-alpha / versionCode 13.

**Verification:** backend regression tests pass (12/12); Kotlin parser-only syntax check performed. Android compilation and device playback/export testing remain unavailable here.

## 1.9 Alpha — subtitle timing and color controls

- Subtitle Studio now provides a selectable word list and an editor for the selected word's text, start time, and end time.
- Per-word timing edits are saved back into transcript word timestamps and consumed by the timed caption overlay during export.
- Caption style now includes color swatches (yellow, white, cyan, pink, green, orange) in addition to existing preset, size, and placement controls.
- Caption overlay uses the saved custom color when one is selected; existing preset colors remain fallback behavior.
- Full transcript text editing remains available; same word-count edits preserve word timing, while word-count changes estimate timings across the original transcript duration.
- Version metadata updated to 1.9.0-alpha / versionCode 14.

**Verification:** backend regression tests pass (12/12); Kotlin syntax-marker check reports no parser errors. Android compilation, visual preview accuracy, and device export are not verified in this environment.


## 2.0 Alpha — subtitle timing preview integration

- Subtitle Studio now has a caption-timing preview scrubber based on the word timestamp track.
- The preview displays the caption chunk that would be active at the selected time, using the same five-word grouping model as the export overlay, plus an active-word indicator.
- Selecting a word jumps the preview time to that word. Adjusting its start/end timing updates the preview's active timing before saving.
- Full transcript edits are reflected in the preview for tokens aligned with the existing word timestamp track; if token count changes, export still estimates timestamps across the transcript span when saving.
- Version metadata updated to 2.0.0-alpha / versionCode 15.

**Verification:** backend tests pass (12/12); Python syntax checks passed; Kotlin parser-only syntax-marker check found no syntax errors. Android compilation, preview visual accuracy, and device export remain unverified.


## 2.1 Alpha — caption animation & visual effects

- Added animation controls in Subtitle Studio: None, Pop, Bounce, Fade, and Slide Up.
- Animation selection is stored in caption style settings and carried into export.
- Media3 canvas caption overlay animates each active word's caption group using source word timing; Pop/Bounce scale, Fade opacity, and Slide Up vertical movement are rendered in export.
- Subtitle Studio preview applies the selected animation effect based on the active word and preview scrubber position.
- Version metadata updated to 2.1.0-alpha / versionCode 16.

**Verification:** backend regression tests and Python syntax checks run. Kotlin parser-only check; Android compilation and real export/device visuals remain unverified.


## ClipForge 2.2 Alpha — Brand Kit & Reusable Caption Presets

- Added a device-local reusable caption Brand Kit store (up to 30 named presets).
- Save current caption preset, size, position, custom color, animation, and optional brand/watermark text under a name.
- Load saved styles into Subtitle Studio for reuse across projects.
- Optional brand/watermark text is previewed in Subtitle Studio and rendered in the export caption overlay.
- Presets are stored in app SharedPreferences locally; they do not sync or transfer between devices.
- App version bumped to 2.2.0-alpha (versionCode 17).

Validation is source-level only in this environment; Android SDK/Gradle/device export are not available.


## 2.3 Alpha — Export Studio
- Export size options: 720p and 1080p.
- Vertical output targets 720×1280 or 1080×1920; horizontal output targets 1280×720 or 1920×1080.
- Selected output resolution is passed to the Media3 export worker.
- Frame rate follows the source video in this milestone; explicit 30/60 FPS controls are not implemented. Encoder bitrate uses Media3 defaults.
- Existing background WorkManager export progress notifications remain in place.

### APK build status
This environment has Java but no Gradle executable, Android SDK, Android build-tools, or Gradle wrapper, and outbound network access is unavailable. An APK could not be produced here. A GitHub Actions workflow (`.github/workflows/android-apk.yml`) has been added to build a debug APK on GitHub-hosted Android runners after the source is pushed to a repository.

## 2.4 Alpha — APK CI readiness

- GitHub Actions workflow now runs backend regression tests first, then builds the Android debug APK on a hosted runner.
- The APK job verifies the APK exists, records file size and SHA-256 in the run summary, and uploads `app-debug.apk` as `ClipForge-debug-apk` for 14 days.
- Workflow supports manual `workflow_dispatch` and pushes to `main`/`master`.
- This environment cannot execute the hosted workflow; no APK is claimed until the Actions run succeeds and the artifact is downloaded/verified.

### Trigger the build
1. Push the project contents (including `.github/workflows/android-apk.yml`) to a GitHub repository on `main` or `master`.
2. Open **Actions → ClipForge Android CI and APK**. Select **Run workflow** for a manual run, or push to the branch.
3. Wait for both backend tests and Android build jobs to pass.
4. Download the `ClipForge-debug-apk` artifact from that run and extract `app-debug.apk`.
5. Transfer/install on Android. This is a debug APK and is not a signed release build for Play Store distribution.


## 2.5 Alpha — CI hardening and mobile-first APK instructions

- Android CI now runs on pushes, pull requests, and manual workflow dispatch.
- Explicit SDK license acceptance and platform-tools installation were added to the hosted Android build.
- Failure guidance is written to the Actions run summary.
- App version bumped to 2.5.0-alpha (version code 19).
- CI still produces a debug APK artifact only; it is not a Play Store release signing configuration.

### APK build steps from a phone
1. Create a GitHub repository (public or private).
2. Upload the extracted **project contents** to the repository root; do not upload only the outer ZIP. Keep `.github/workflows/android-apk.yml` included.
3. Open the repository's Actions tab and choose **ClipForge Android CI and APK**.
4. Select **Run workflow** on the main branch. Wait for the backend test job, then the Android APK job.
5. In the successful run's Artifacts section, download `ClipForge-debug-apk`; unzip it and install `app-debug.apk`. Android may prompt to allow installs from the browser/file manager.
6. If the run fails, open the failed job and copy the first red step's error log to ChatGPT for troubleshooting.

### CI triggers and outputs
- Push to `main`/`master`, pull requests to those branches, or manual workflow dispatch.
- Backend pytest suite runs before Android assembly.
- APK artifact retention: 14 days.
- APK size and SHA-256 are recorded in the run summary.
