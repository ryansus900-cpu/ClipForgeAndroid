# ClipForge STT backend (developer starter)

This starter accepts the app's multipart upload (`video` + `language`) at `POST /api/transcribe`, extracts audio with FFmpeg, segments long audio, and returns detected language plus timestamped words.

## Setup

- Python 3.10+
- FFmpeg installed and on `PATH`
- An OpenAI API key stored **only on the server** as `OPENAI_API_KEY`

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="..."
uvicorn server:app --host 0.0.0.0 --port 8000
```

Set the Android project's `CLIPFORGE_API_BASE` Gradle property to your HTTPS backend base URL (or the emulator's `http://10.0.2.2:8000` for local testing). The Android app must be rebuilt after configuring this.

## Security before public deployment

This is a development-only sample, **not safe to expose publicly**. Add authentication, per-user quotas, rate limiting, abuse controls, request-size limits at the reverse proxy, HTTPS, privacy/retention policy, secure temporary-file cleanup, and billing protections before hosting. Do not embed OpenAI keys in the Android APK. Restrict deployment access to trusted testers first.

The sample uses `whisper-1` because the current word-timestamp feature is supported there. OpenAI's current speech-to-text docs describe word timestamps as a compatibility workflow on that model and mark it deprecated with a stated shutdown date of Feb 26, 2027. Revisit the transcription provider before production.
