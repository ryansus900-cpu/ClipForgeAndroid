"""Transcript-only clip discovery heuristics. Scores are estimates, not virality guarantees."""
from __future__ import annotations
import re
from typing import Any

HOOK_WORDS = {
    "en": ["secret", "never", "stop", "mistake", "truth", "why", "how", "imagine", "wait", "crazy", "shocking", "because", "nobody", "everyone", "actually", "money", "million", "fail", "success"],
    "hi": ["क्यों", "कैसे", "सच", "गलती", "रुको", "पैसा", "करोड़", "सफलता", "असफल", "मत", "कभी", "सबसे"],
}
EMOTION_WORDS = ["love", "hate", "angry", "fear", "happy", "sad", "excited", "crazy", "amazing", "terrible", "beautiful", "heart", "shock", "surprise", "मज़ा", "गुस्सा", "डर", "खुशी", "दुख", "अद्भुत", "प्यार"]
MOTIVATION_WORDS = ["believe", "discipline", "努力", "work hard", "dream", "success", "failure", "focus", "keep going", " मेहनत", "सपना", "सफलता", "हार", "जीत", "लक्ष्य", "विश्वास"]
FUNNY_WORDS = ["funny", "joke", "laugh", "hilarious", "stupid", "ridiculous", " मज़ाक", "हंसी", "हंस", "बेवकूफ"]
MONEY_WORDS = ["money", "dollar", "rupee", "income", "salary", "business", "profit", "million", "billion", "पैसा", "कमाई", "रुपया", "व्यापार"]


def _word_text(w: dict[str, Any]) -> str:
    return str(w.get("text", "")).strip()


def _make_units(words: list[dict[str, Any]]) -> list[dict[str, Any]]:
    units, start = [], 0
    for i, w in enumerate(words):
        txt = _word_text(w)
        end_sentence = bool(re.search(r"[.!?।॥]$", txt))
        gap = 0.0
        if i + 1 < len(words):
            gap = max(0.0, float(words[i + 1].get("start", 0)) - float(w.get("end", 0)))
        if end_sentence or gap >= 1.25 or i == len(words) - 1:
            segment = words[start:i + 1]
            if segment:
                units.append({"words": segment, "start": float(segment[0].get("start", 0)), "end": float(segment[-1].get("end", 0)), "text": " ".join(_word_text(x) for x in segment)})
            start = i + 1
    return units


def _clip_type(text: str) -> str:
    low = text.lower()
    if any(x in low for x in FUNNY_WORDS): return "funny"
    if any(x in low for x in MOTIVATION_WORDS): return "motivational"
    if any(x in low for x in MONEY_WORDS): return "money/business"
    if any(x in low for x in EMOTION_WORDS): return "emotional"
    return "informative"


def _score(text: str, duration: float, start: float, end: float) -> tuple[int, dict[str, int], list[str]]:
    low = text.lower()
    hook_hits = sum(1 for w in HOOK_WORDS["en"] + HOOK_WORDS["hi"] if w in low)
    has_question = "?" in text or "؟" in text
    hook = min(100, 38 + hook_hits * 12 + (12 if has_question else 0) + (10 if start <= 3 else 0))
    emotion_hits = sum(1 for w in EMOTION_WORDS if w in low)
    emotion = min(100, 30 + emotion_hits * 18 + (10 if "!" in text else 0))
    completeness = 80 if re.search(r"[.!?।॥]$", text.strip()) else 58
    if len(text.split()) < 8: completeness -= 15
    if len(text.split()) > 105: completeness -= 15
    completeness = max(10, min(100, completeness))
    duration_score = 100 if 20 <= duration <= 50 else (82 if 15 <= duration <= 60 else (65 if 8 <= duration <= 75 else 35))
    pace = 72  # Transcript-only estimate: actual speech energy/pace is not measured yet.
    score = round(hook * .30 + emotion * .20 + completeness * .25 + duration_score * .15 + pace * .10)
    reasons = []
    if hook_hits: reasons.append("Contains hook-style words or phrases")
    if has_question: reasons.append("Opens or develops a question")
    if emotion_hits: reasons.append("Emotion-related language detected")
    if completeness >= 75: reasons.append("Ends at a complete thought")
    if 20 <= duration <= 50: reasons.append("Good short-form duration range")
    if not reasons: reasons.append("Selected as a concise standalone transcript segment")
    return score, {"hook": hook, "emotion": emotion, "completeness": completeness, "duration": duration_score, "pace_estimate": pace}, reasons


def analyze_transcript(words: list[dict[str, Any]], clip_count: int = 8, prompt: str = "") -> list[dict[str, Any]]:
    if not words: return []
    valid = [w for w in words if _word_text(w) and float(w.get("end", 0)) >= float(w.get("start", 0))]
    if not valid: return []
    units = _make_units(valid)
    windows = []
    for i in range(len(units)):
        for j in range(i, min(len(units), i + 5)):
            start, end = units[i]["start"], units[j]["end"]
            duration = max(0.0, end - start)
            if duration > 75: break
            if duration < 8: continue
            seg_words = [w for unit in units[i:j + 1] for w in unit["words"]]
            text = " ".join(_word_text(w) for w in seg_words)
            score, dimensions, reasons = _score(text, duration, start, end)
            category = _clip_type(text)
            # User prompt is a soft preference; don't force an unsupported category.
            p = prompt.lower().strip()
            if p and any(k in p for k in ["funny", "humor", "comedy"]) and category == "funny": score = min(100, score + 8)
            if p and any(k in p for k in ["motiv", "inspir"]) and category == "motivational": score = min(100, score + 8)
            if p and any(k in p for k in ["money", "business"]) and category == "money/business": score = min(100, score + 8)
            windows.append({"start_seconds": round(start, 3), "end_seconds": round(end, 3), "duration_seconds": round(duration, 2), "text": text, "score": score, "category": category, "score_breakdown": dimensions, "reasons": reasons})
    windows.sort(key=lambda c: (c["score"], -c["duration_seconds"]), reverse=True)
    selected = []
    for candidate in windows:
        # Reduce duplicate suggestions by rejecting candidates with >65% temporal overlap.
        c0, c1 = candidate["start_seconds"], candidate["end_seconds"]
        duplicate = False
        for chosen in selected:
            overlap = max(0, min(c1, chosen["end_seconds"]) - max(c0, chosen["start_seconds"]))
            shorter = min(c1 - c0, chosen["end_seconds"] - chosen["start_seconds"])
            if shorter > 0 and overlap / shorter > .65:
                duplicate = True; break
        if not duplicate: selected.append(candidate)
        if len(selected) >= max(1, min(10, clip_count)): break
    # Sequential display order for reviewing a source video, while rank is preserved explicitly.
    selected.sort(key=lambda c: c["start_seconds"])
    for rank, item in enumerate(selected, 1): item["rank"] = rank
    return selected
