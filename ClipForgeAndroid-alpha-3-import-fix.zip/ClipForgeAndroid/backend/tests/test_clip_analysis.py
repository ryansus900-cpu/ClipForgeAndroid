import unittest
from clip_analysis import analyze_transcript


def make_words(sentences, start=0.0):
    result = []
    t = start
    for sentence in sentences:
        parts = sentence.split()
        for i, token in enumerate(parts):
            result.append({"text": token, "start": round(t, 2), "end": round(t + 0.45, 2)})
            t += 0.48
        t += 1.2
    return result


class ClipAnalysisTests(unittest.TestCase):
    def test_returns_ranked_candidates_and_timestamps(self):
        words = make_words([
            "Stop making this mistake because nobody tells you the truth.",
            "The secret is to focus on one goal and keep going.",
            "Imagine how your life changes when you build discipline.",
            "This is the most important lesson about money and success.",
        ])
        clips = analyze_transcript(words, clip_count=5)
        self.assertGreaterEqual(len(clips), 1)
        self.assertLessEqual(len(clips), 5)
        self.assertTrue(all(c["end_seconds"] > c["start_seconds"] for c in clips))
        self.assertTrue(all(0 <= c["score"] <= 100 for c in clips))
        self.assertTrue(all("score_breakdown" in c and "reasons" in c for c in clips))

    def test_empty_words_returns_empty(self):
        self.assertEqual(analyze_transcript([]), [])

    def test_prompt_preference_increases_category_score(self):
        words = make_words(["This funny joke makes everyone laugh and it is hilarious.", "Stop and listen because this is the truth."])
        general = analyze_transcript(words, 3)
        prompted = analyze_transcript(words, 3, "funny moments")
        general_funny = next((x for x in general if x["category"] == "funny"), None)
        prompted_funny = next((x for x in prompted if x["category"] == "funny"), None)
        if general_funny and prompted_funny:
            self.assertGreaterEqual(prompted_funny["score"], general_funny["score"])

if __name__ == "__main__": unittest.main()
