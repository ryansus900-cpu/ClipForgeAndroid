import struct
from audio_intelligence import analyze_pcm16_mono, estimate_pace_from_words

def _samples(values):
    return struct.pack("<" + "h" * len(values), *values)

def test_silence_detected_and_loud_signal_not():
    sr=16000
    silent=_samples([0]*sr)
    loud=_samples([12000]*sr)
    result=analyze_pcm16_mono([silent+loud],sample_rate=sr,window_seconds=.5)
    assert result["duration_seconds"] == 2.0
    assert len(result["silence_segments"]) == 1
    assert result["silence_segments"][0]["start_seconds"] == 0.0
    assert result["silence_ratio"] == 0.5
    assert result["peak_dbfs"] > -10

def test_pace_estimate_is_transcript_count_not_audio_model():
    words=[{"text":"hello"},{"text":"there"},{"text":"friend"}]
    assert estimate_pace_from_words(words,3) == 60.0
    assert estimate_pace_from_words([],3) is None
    assert estimate_pace_from_words(words,0) is None

def test_empty_stream():
    result=analyze_pcm16_mono([],sample_rate=16000)
    assert result["duration_seconds"] == 0
    assert result["silence_segments"] == []
