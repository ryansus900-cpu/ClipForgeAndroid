from speech_cleanup import detect_fillers, speech_pace, propose_cleanup


def test_detect_fillers_single_and_hinglish_and_hindi():
    words=[
        {"text":"Um", "start":0.0,"end":0.2},
        {"text":"I", "start":0.3,"end":0.4},
        {"text":"think", "start":0.4,"end":0.6},
        {"text":"matlab", "start":1.0,"end":1.3},
        {"text":"अच्छा", "start":1.5,"end":1.7},
    ]
    result=detect_fillers(words)
    assert [x["text"] for x in result] == ["Um","matlab","अच्छा"]


def test_pace_timestamped_word_count():
    words=[{"text":"one","start":0,"end":.2},{"text":"two","start":1,"end":1.2},{"text":"three","start":2,"end":2.2}]
    pace=speech_pace(words)
    assert pace["overall_wpm"] == 81.8
    assert pace["windowed"] == []
    assert speech_pace([])["overall_wpm"] is None


def test_cleanup_suggestions_review_only():
    words=[{"text":"uh","start":3.0,"end":3.2}]
    silences=[{"start_seconds":1.0,"end_seconds":2.0}]
    suggestions=propose_cleanup(words,silences)
    assert len(suggestions)==2
    assert all(s["requires_review"] for s in suggestions)
    assert any(s["reason"]=="long_silence" and s["recommended"] for s in suggestions)
    assert any(s["reason"]=="filler_word" and not s["recommended"] for s in suggestions)
