from audio_clip_scoring import score_candidates_with_audio

def _clip(score=80):
    return {"start_seconds": 1, "end_seconds": 4, "score": score, "score_breakdown": {}, "reasons": []}

def test_audio_continuity_bumps_score_and_records_breakdown():
    clip = _clip()
    features = {"windows": [
        {"start_seconds": 0.5, "end_seconds": 1.5, "rms_dbfs": -22, "is_silence": False},
        {"start_seconds": 1.5, "end_seconds": 2.5, "rms_dbfs": -20, "is_silence": False},
        {"start_seconds": 2.5, "end_seconds": 3.5, "rms_dbfs": -25, "is_silence": False},
    ]}
    result = score_candidates_with_audio([clip], features)[0]
    assert result["score"] >= 80
    assert result["score_breakdown"]["audio_signal"] == 100

def test_silence_penalizes_audio_score():
    clip = _clip()
    features = {"windows": [
        {"start_seconds": 1, "end_seconds": 2, "rms_dbfs": -80, "is_silence": True},
        {"start_seconds": 2, "end_seconds": 3, "rms_dbfs": -80, "is_silence": True},
    ]}
    result = score_candidates_with_audio([clip], features)[0]
    assert result["score"] < 80
    assert result["score_breakdown"]["audio_signal"] == 0

def test_without_audio_features_keeps_transcript_score():
    clip = _clip()
    result = score_candidates_with_audio([clip], None)[0]
    assert result["score"] == 80
