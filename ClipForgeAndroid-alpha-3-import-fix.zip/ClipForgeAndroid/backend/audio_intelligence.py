"""Audio signal summaries for ClipForge. These are measurable features, not emotion/virality ground truth."""
from __future__ import annotations
import math
import struct
from typing import Iterable

WINDOW_SECONDS = 0.5
SILENCE_RMS_DBFS = -42.0

def _db(value: float) -> float:
    return 20.0 * math.log10(max(value, 1e-9))

def analyze_pcm16_mono(chunks: Iterable[bytes], sample_rate: int = 16000,
                       window_seconds: float = WINDOW_SECONDS) -> dict:
    """Analyze streaming PCM16 chunks; avoids buffering a complete audio track."""
    window_samples = max(1, int(sample_rate * window_seconds))
    pending = bytearray()
    energies, peaks = [], []
    total_samples = 0
    for chunk in chunks:
        pending.extend(chunk)
        while len(pending) >= window_samples * 2:
            raw = pending[:window_samples * 2]
            del pending[:window_samples * 2]
            vals = struct.unpack("<" + "h" * window_samples, raw)
            norm = [v / 32768.0 for v in vals]
            energies.append(math.sqrt(sum(v*v for v in norm) / len(norm)))
            peaks.append(max(abs(v) for v in norm))
            total_samples += window_samples
    if pending:
        even = len(pending) - (len(pending) % 2)
        if even:
            vals = struct.unpack("<" + "h" * (even // 2), pending[:even])
            norm = [v / 32768.0 for v in vals]
            energies.append(math.sqrt(sum(v*v for v in norm) / max(1, len(norm))))
            peaks.append(max(abs(v) for v in norm))
            total_samples += len(norm)
    if not energies:
        return {"duration_seconds": 0.0, "windows": [], "silence_segments": [],
                "silence_ratio": 0.0, "average_rms_dbfs": -120.0,
                "peak_dbfs": -120.0, "energy_change_points": [], "speech_pace_wpm": None}
    duration = total_samples / sample_rate
    windows = []
    for i, rms in enumerate(energies):
        start = i * window_seconds
        end = min(duration, start + window_seconds)
        windows.append({"start_seconds": round(start, 3), "end_seconds": round(end, 3),
                      "rms_dbfs": round(_db(rms), 2), "peak_dbfs": round(_db(peaks[i]), 2),
                      "is_silence": _db(rms) < SILENCE_RMS_DBFS})
    silences, current = [], None
    for w in windows:
        if w["is_silence"]:
            if current is None:
                current = {"start_seconds": w["start_seconds"], "end_seconds": w["end_seconds"]}
            else:
                current["end_seconds"] = w["end_seconds"]
        elif current:
            if current["end_seconds"] - current["start_seconds"] >= 0.35:
                silences.append(current)
            current = None
    if current and current["end_seconds"] - current["start_seconds"] >= 0.35:
        silences.append(current)
    changes = []
    for i in range(1, len(windows)):
        delta = windows[i]["rms_dbfs"] - windows[i-1]["rms_dbfs"]
        if abs(delta) >= 12:
            changes.append({"at_seconds": windows[i]["start_seconds"], "delta_db": round(delta, 2)})
    avg_rms = math.sqrt(sum(x*x for x in energies) / len(energies))
    silence_duration = sum(s["end_seconds"] - s["start_seconds"] for s in silences)
    return {"duration_seconds": round(duration, 3), "windows": windows,
            "silence_segments": silences, "silence_ratio": round(min(1.0, silence_duration / max(duration, 1e-9)), 4),
            "average_rms_dbfs": round(_db(avg_rms), 2), "peak_dbfs": round(_db(max(peaks)), 2),
            "energy_change_points": changes, "speech_pace_wpm": None,
            "notes": "Energy-based silence detection only; laughter, emotion, speaker identity and true speech pace require separate models."}

def estimate_pace_from_words(words: list[dict], audio_duration: float) -> float | None:
    """Word-count pace estimate from transcript; not acoustic speaking rate."""
    if audio_duration <= 0 or not words:
        return None
    count = sum(1 for w in words if str(w.get("text", "")).strip())
    return round(count / audio_duration * 60, 1)
