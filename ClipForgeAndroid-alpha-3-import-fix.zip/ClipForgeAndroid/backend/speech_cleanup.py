"""Transcript-aware cleanup recommendations; suggestions only, never destructive edits."""
from __future__ import annotations
import re
import unicodedata
from typing import Any

EN_FILLERS = {"um", "umm", "uh", "uhh", "erm", "er", "hmm", "hm", "like", "you know", "i mean", "basically", "actually"}
HI_FILLERS = {"मतलब", "अच्छा", "तो", "हां", "हाँ", "अरे", "देखो", "यार", "ना", "हम्म"}
HINGLISH_FILLERS = {"matlab", "achha", "acha", "haan", "han", "arey", "dekho", "yaar", "hmm", "basically", "like", "you know"}


def norm(text: str) -> str:
    return " ".join("".join(ch for ch in text.lower() if unicodedata.category(ch)[0] in {"L", "M", "N"}).split())


def detect_fillers(words: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Identify exact single/multi-word filler phrases from timed word records."""
    valid = [w for w in words if str(w.get("text", "")).strip()]
    results: list[dict[str, Any]] = []
    i = 0
    while i < len(valid):
        token = norm(str(valid[i].get("text", "")))
        matched = None
        matched_count = 1
        if token in EN_FILLERS | HI_FILLERS | HINGLISH_FILLERS:
            matched = token
        # Recognize common two-token filler phrases, where tokenizer splits them.
        if i + 1 < len(valid):
            pair = token + " " + norm(str(valid[i + 1].get("text", "")))
            if pair in EN_FILLERS | HI_FILLERS | HINGLISH_FILLERS:
                matched, matched_count = pair, 2
        if matched:
            group = valid[i:i + matched_count]
            start = float(group[0].get("start", 0.0))
            end = float(group[-1].get("end", start))
            results.append({"text": " ".join(str(w.get("text", "")).strip() for w in group),
                           "normalized": matched, "start_seconds": round(start, 3),
                           "end_seconds": round(end, 3), "duration_seconds": round(max(0, end-start), 3),
                           "kind": "filler_word", "confidence": "lexical_match"})
            i += matched_count
        else:
            i += 1
    return results


def speech_pace(words: list[dict[str, Any]]) -> dict[str, Any]:
    timed = [w for w in words if str(w.get("text", "")).strip() and float(w.get("end", 0)) > float(w.get("start", 0))]
    if not timed:
        return {"overall_wpm": None, "windowed": [], "note": "No valid timed transcript words."}
    first = min(float(w["start"]) for w in timed)
    last = max(float(w["end"]) for w in timed)
    span = max(0.001, last-first)
    overall = round(len(timed) / span * 60, 1)
    # Approximate 15-second buckets by timestamps, with 5-second stride.
    buckets=[]
    start=first
    while start < last:
        end=min(last, start+15)
        count=sum(1 for w in timed if float(w["start"]) >= start and float(w["start"]) < end)
        if end-start >= 5:
            buckets.append({"start_seconds": round(start,2), "end_seconds": round(end,2), "wpm": round(count/(end-start)*60,1), "word_count": count})
        start += 5
    return {"overall_wpm": overall, "windowed": buckets,
            "note": "Timestamp-derived transcript pace estimate; not an acoustic speech-rate model."}


def propose_cleanup(words: list[dict[str, Any]], silence_segments: list[dict[str, Any]],
                   min_silence_seconds: float = 0.6, padding_seconds: float = 0.08) -> list[dict[str, Any]]:
    """Build non-destructive cut recommendations for long pauses and fillers."""
    cuts=[]
    for silence in silence_segments:
        start=float(silence.get("start_seconds",0)); end=float(silence.get("end_seconds",start))
        if end-start >= min_silence_seconds:
            cuts.append({"start_seconds": round(start+padding_seconds,3), "end_seconds": round(max(start+padding_seconds,end-padding_seconds),3),
                        "reason":"long_silence", "source_interval": {"start_seconds":start,"end_seconds":end},
                        "recommended": True, "requires_review": True})
    for filler in detect_fillers(words):
        start=float(filler["start_seconds"]); end=float(filler["end_seconds"])
        cuts.append({"start_seconds": round(max(0,start-padding_seconds),3), "end_seconds":round(end+padding_seconds,3),
                    "reason":"filler_word", "text":filler["text"], "recommended":False, "requires_review":True})
    cuts.sort(key=lambda c:c["start_seconds"])
    # Do not auto-merge overlapping suggestions; preserve individual reasons for UI review.
    return cuts
