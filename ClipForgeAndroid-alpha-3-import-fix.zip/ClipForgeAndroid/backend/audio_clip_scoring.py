"""Combine transcript clip candidates with optional audio-energy features."""
from __future__ import annotations
from typing import Any


def score_candidates_with_audio(clips: list[dict[str, Any]], audio: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Adjust transcript scores using silence and energy changes in each clip window.

    This deliberately uses only measurable signal summaries. It is not emotion,
    laughter, semantic understanding, or a viral prediction model.
    """
    if not audio or not isinstance(audio.get("windows"), list):
        return clips
    windows = audio["windows"]
    for clip in clips:
        start = float(clip.get("start_seconds", 0))
        end = float(clip.get("end_seconds", start))
        relevant = [w for w in windows if float(w.get("end_seconds", 0)) > start and float(w.get("start_seconds", 0)) < end]
        if not relevant or end <= start:
            clip.setdefault("score_breakdown", {})["audio_signal"] = 50
            clip.setdefault("reasons", []).append("Audio signal data unavailable for this time range")
            continue
        silences = [w for w in relevant if w.get("is_silence")]
        silence_fraction = len(silences) / len(relevant)
        # Higher scores for continuous audible material, bounded to avoid dominating text features.
        continuity = max(0, min(100, round(100 - silence_fraction * 100)))
        energy_values = [float(w.get("rms_dbfs", -120)) for w in relevant]
        audible = sum(v > -42 for v in energy_values) / len(energy_values)
        energy_score = round(audible * 100)
        audio_score = round(continuity * .7 + energy_score * .3)
        old_score = int(clip.get("score", 50))
        new_score = max(0, min(100, round(old_score * .85 + audio_score * .15)))
        clip["score"] = new_score
        clip.setdefault("score_breakdown", {})["audio_signal"] = audio_score
        clip.setdefault("score_breakdown", {})["silence_continuity"] = continuity
        clip.setdefault("reasons", []).append(
            "Audio continuity analyzed; fewer low-energy windows favored" if silence_fraction < .25
            else "Audio contains noticeable low-energy intervals"
        )
    clips.sort(key=lambda c: c.get("score", 0), reverse=True)
    for rank, clip in enumerate(clips, 1):
        clip["rank"] = rank
    return clips
