"""Development transcription backend for ClipForge. Deploy behind authentication/rate limits."""
import os
import subprocess
import tempfile
import time
import uuid
import shutil
from pathlib import Path
from typing import Optional, Dict, Any

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, BackgroundTasks
from fastapi.responses import FileResponse
from openai import OpenAI
from pydantic import BaseModel, HttpUrl

app = FastAPI(title="ClipForge STT Backend", version="0.2.0")
client = OpenAI()

MAX_UPLOAD_MB = int(os.getenv("CLIPFORGE_MAX_UPLOAD_MB", "800"))
MAX_SEGMENT_SECONDS = int(os.getenv("CLIPFORGE_AUDIO_SEGMENT_SECONDS", "600"))
# Temporary storage for URL-imported videos (cleaned after TTL)
URL_IMPORT_DIR = Path(tempfile.gettempdir()) / "clipforge-url-imports"
URL_IMPORT_DIR.mkdir(parents=True, exist_ok=True)
URL_IMPORT_TTL_SECONDS = int(os.getenv("CLIPFORGE_URL_IMPORT_TTL", "3600"))  # 1 hour
# In-memory registry: file_id -> {path, title, duration, created_at, expires_at}
_url_imports: Dict[str, Dict[str, Any]] = {}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/transcribe")
def transcribe(video: UploadFile = File(...), language: str = Form("auto")):
    """Upload video, extract mono 32-kbps MP3, split into 10-min chunks, transcribe word timings."""
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    with tempfile.TemporaryDirectory(prefix="clipforge-stt-") as tmp:
        root = Path(tmp)
        video_path = root / "source_video"
        size = 0
        with video_path.open("wb") as f:
            while chunk := video.file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        audio_path = root / "audio.mp3"
        try:
            subprocess.run([
                "ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "16000",
                "-b:a", "32k", str(audio_path)
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=900)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            raise HTTPException(status_code=422, detail="Audio extraction failed. Check ffmpeg and file validity.") from e

        # Split to keep each API request below its audio upload limit and support long videos.
        chunks = root / "chunk-%03d.mp3"
        try:
            subprocess.run([
                "ffmpeg", "-y", "-i", str(audio_path), "-f", "segment", "-segment_time",
                str(MAX_SEGMENT_SECONDS), "-c", "copy", str(chunks)
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=900)
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=422, detail="Audio segmentation failed") from e

        word_results = []
        detected = "unknown"
        offset = 0.0
        for chunk_file in sorted(root.glob("chunk-*.mp3")):
            if chunk_file.stat().st_size > 24 * 1024 * 1024:
                raise HTTPException(status_code=413, detail="Audio chunk is still over 24 MB; reduce segment size or bitrate")
            with chunk_file.open("rb") as audio:
                kwargs = dict(file=audio, model="whisper-1", response_format="verbose_json", timestamp_granularities=["word"])
                if language and language.lower() != "auto":
                    kwargs["language"] = language
                result = client.audio.transcriptions.create(**kwargs)
            detected = getattr(result, "language", detected) or detected
            for word in (getattr(result, "words", None) or []):
                word_results.append({
                    "text": word.word,
                    "start": float(word.start) + offset,
                    "end": float(word.end) + offset,
                })
            # Get actual segment duration to avoid accumulated offset drift for short final chunks.
            try:
                duration = float(subprocess.check_output([
                    "ffprobe", "-v", "error", "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1", str(chunk_file)
                ], text=True).strip())
            except (subprocess.CalledProcessError, ValueError, FileNotFoundError):
                duration = MAX_SEGMENT_SECONDS
            offset += duration

        return {"detected_language": detected, "words": word_results}

@app.post("/api/audio/analyze")
def analyze_audio(video: UploadFile = File(...), words_json: str = Form("[]")):
    """Stream-decode uploaded video audio and return energy/silence features."""
    import json
    from audio_intelligence import analyze_pcm16_mono, estimate_pace_from_words
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    try:
        words = json.loads(words_json)
        if not isinstance(words, list):
            raise ValueError("words_json must be a list")
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="Invalid words_json")
    with tempfile.TemporaryDirectory(prefix="clipforge-audio-") as tmp:
        video_path = Path(tmp) / "source_video"
        size = 0
        with video_path.open("wb") as f:
            while chunk := video.file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        command = ["ffmpeg", "-v", "error", "-i", str(video_path), "-vn", "-ac", "1",
                   "-ar", "16000", "-f", "s16le", "pipe:1"]
        try:
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            def stream_chunks():
                assert proc.stdout is not None
                while True:
                    data = proc.stdout.read(32000)  # one second of 16-kHz mono PCM
                    if not data:
                        break
                    yield data
            result = analyze_pcm16_mono(stream_chunks(), sample_rate=16000, window_seconds=0.5)
            _, stderr = proc.communicate(timeout=900)
            if proc.returncode != 0:
                raise HTTPException(status_code=422, detail="Audio decoding failed")
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            if 'proc' in locals() and proc.poll() is None:
                proc.kill()
            raise HTTPException(status_code=422, detail="FFmpeg audio analysis failed") from exc
    result["speech_pace_wpm"] = estimate_pace_from_words(words, result["duration_seconds"])
    result["analysis_version"] = "audio_signal_v1"
    return result


@app.post("/api/clips/analyze")
def analyze_clips(payload: dict):
    """Rank timestamped transcript clip candidates; audio_features are optional summaries."""
    from clip_analysis import analyze_transcript
    from audio_clip_scoring import score_candidates_with_audio
    words = payload.get("words", [])
    if not isinstance(words, list):
        raise HTTPException(status_code=422, detail="words must be a JSON array")
    try:
        clip_count = int(payload.get("clip_count", 8))
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="clip_count must be an integer")
    clip_count = max(1, min(10, clip_count))
    prompt = str(payload.get("prompt", ""))[:500]
    clips = analyze_transcript(words, clip_count=clip_count, prompt=prompt)
    audio_features = payload.get("audio_features")
    clips = score_candidates_with_audio(clips, audio_features)
    return {"clips": clips, "scoring_mode": "transcript_plus_audio" if audio_features else "transcript_only",
            "note": "Heuristic ranking; scores are estimates, not guaranteed virality."}

@app.post("/api/audio/cleanup/analyze")
def analyze_cleanup(video: UploadFile = File(...), words_json: str = Form("[]")):
    """Return audio silence, transcript filler, pace, and non-destructive cut suggestions."""
    import json
    from audio_intelligence import analyze_pcm16_mono
    from speech_cleanup import detect_fillers, speech_pace, propose_cleanup
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    try:
        words=json.loads(words_json)
        if not isinstance(words,list): raise ValueError("words must be list")
    except (ValueError,TypeError):
        raise HTTPException(status_code=422, detail="Invalid words_json")
    with tempfile.TemporaryDirectory(prefix="clipforge-cleanup-") as tmp:
        video_path=Path(tmp)/"source_video"
        size=0
        with video_path.open("wb") as f:
            while chunk:=video.file.read(1024*1024):
                size+=len(chunk)
                if size>MAX_UPLOAD_MB*1024*1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        command=["ffmpeg","-v","error","-i",str(video_path),"-vn","-ac","1","-ar","16000","-f","s16le","pipe:1"]
        try:
            proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            def chunks():
                assert proc.stdout is not None
                while True:
                    data=proc.stdout.read(32000)
                    if not data: break
                    yield data
            audio=analyze_pcm16_mono(chunks(),sample_rate=16000,window_seconds=.5)
            _,err=proc.communicate(timeout=900)
            if proc.returncode:
                raise HTTPException(status_code=422,detail="Audio decoding failed")
        except (FileNotFoundError,subprocess.TimeoutExpired) as exc:
            if 'proc' in locals() and proc.poll() is None: proc.kill()
            raise HTTPException(status_code=422,detail="FFmpeg cleanup analysis failed") from exc
    fillers=detect_fillers(words)
    pace=speech_pace(words)
    suggestions=propose_cleanup(words,audio.get("silence_segments",[]))
    return {"analysis_version":"speech_cleanup_v1", "audio":audio, "fillers":fillers,
            "pace":pace, "cut_suggestions":suggestions,
            "note":"Suggestions are non-destructive and require user review. Filler detection is lexical and may misclassify words used meaningfully."}


# ---------------------------------------------------------------------------
# URL import (YouTube / TikTok / Instagram via yt-dlp)
# ---------------------------------------------------------------------------

class UrlImportRequest(BaseModel):
    url: str
    language: str = "auto"
    max_height: int = 720  # keep downloads reasonable for mobile


def _cleanup_expired_imports():
    now = time.time()
    expired = [fid for fid, meta in _url_imports.items() if meta["expires_at"] < now]
    for fid in expired:
        meta = _url_imports.pop(fid, None)
        if meta and meta.get("path"):
            try:
                Path(meta["path"]).unlink(missing_ok=True)
            except Exception:
                pass


def _is_supported_url(url: str) -> bool:
    u = url.lower()
    return any(
        host in u
        for host in (
            "youtube.com", "youtu.be", "m.youtube.com",
            "tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
            "instagram.com", "instagr.am",
        )
    )


@app.post("/api/import/url")
def import_from_url(req: UrlImportRequest, background_tasks: BackgroundTasks):
    """
    Download a public video from YouTube / TikTok / Instagram using yt-dlp.
    Returns a short-lived file_id the Android client can download.
    Only use this for content the user owns or has explicit rights to process.
    """
    _cleanup_expired_imports()
    url = (req.url or "").strip()
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    if not _is_supported_url(url):
        raise HTTPException(
            status_code=400,
            detail="Only YouTube, TikTok and Instagram links are supported in this alpha.",
        )

    file_id = str(uuid.uuid4())
    out_dir = URL_IMPORT_DIR / file_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_template = str(out_dir / "video.%(ext)s")

    # Prefer progressive mp4, limit height for mobile-friendly size
    ydl_opts = [
        "yt-dlp",
        "--no-playlist",
        "--no-warnings",
        "-f", f"bv*[height<={req.max_height}][ext=mp4]+ba[ext=m4a]/b[height<={req.max_height}][ext=mp4]/b",
        "--merge-output-format", "mp4",
        "-o", out_template,
        "--print", "after_move:filepath",
        "--print", "title",
        "--print", "duration",
        "--no-mtime",
        url,
    ]

    try:
        result = subprocess.run(
            ydl_opts,
            capture_output=True,
            text=True,
            timeout=900,
            check=False,
        )
    except FileNotFoundError:
        raise HTTPException(
            status_code=500,
            detail="yt-dlp is not installed on the server. Run: pip install yt-dlp",
        )
    except subprocess.TimeoutExpired:
        shutil.rmtree(out_dir, ignore_errors=True)
        raise HTTPException(status_code=504, detail="Download timed out (15 min limit)")

    if result.returncode != 0:
        shutil.rmtree(out_dir, ignore_errors=True)
        err = (result.stderr or result.stdout or "unknown error")[:400]
        raise HTTPException(
            status_code=422,
            detail=f"Could not download video. It may be private, age-restricted, region-locked or blocked. Details: {err}",
        )

    lines = [ln.strip() for ln in (result.stdout or "").splitlines() if ln.strip()]
    if len(lines) < 1:
        shutil.rmtree(out_dir, ignore_errors=True)
        raise HTTPException(status_code=422, detail="yt-dlp produced no output file")

    # Last non-empty lines are usually: filepath, title, duration (because of --print order)
    # Safer: find the actual file
    video_files = list(out_dir.glob("video.*"))
    if not video_files:
        shutil.rmtree(out_dir, ignore_errors=True)
        raise HTTPException(status_code=422, detail="Download finished but no video file found")
    video_path = video_files[0]

    title = "Imported video"
    duration = 0.0
    # Parse printed metadata if present
    for ln in lines:
        if ln.endswith((".mp4", ".mkv", ".webm", ".mov")) and Path(ln).exists():
            video_path = Path(ln)
        elif ln.replace(".", "", 1).isdigit():
            try:
                duration = float(ln)
            except ValueError:
                pass
        elif not ln.startswith("/") and len(ln) > 3:
            title = ln[:200]

    # Fallback duration via ffprobe
    if duration <= 0:
        try:
            duration = float(
                subprocess.check_output(
                    [
                        "ffprobe", "-v", "error",
                        "-show_entries", "format=duration",
                        "-of", "default=noprint_wrappers=1:nokey=1",
                        str(video_path),
                    ],
                    text=True,
                ).strip()
            )
        except Exception:
            duration = 0.0

    expires_at = time.time() + URL_IMPORT_TTL_SECONDS
    _url_imports[file_id] = {
        "path": str(video_path),
        "title": title,
        "duration": duration,
        "created_at": time.time(),
        "expires_at": expires_at,
        "size": video_path.stat().st_size,
    }

    # Schedule cleanup
    background_tasks.add_task(_cleanup_expired_imports)

    return {
        "file_id": file_id,
        "title": title,
        "duration_seconds": round(duration, 2),
        "size_bytes": video_path.stat().st_size,
        "download_path": f"/api/import/{file_id}/download",
        "expires_in_seconds": URL_IMPORT_TTL_SECONDS,
        "note": "Temporary file. Download promptly. Only import content you have rights to use.",
    }


@app.get("/api/import/{file_id}/download")
def download_imported_video(file_id: str):
    """Stream a previously imported video. Files expire after the configured TTL."""
    _cleanup_expired_imports()
    meta = _url_imports.get(file_id)
    if not meta:
        raise HTTPException(status_code=404, detail="File not found or already expired")
    path = Path(meta["path"])
    if not path.is_file():
        _url_imports.pop(file_id, None)
        raise HTTPException(status_code=404, detail="File missing on disk")
    return FileResponse(
        path,
        media_type="video/mp4",
        filename=f"{meta.get('title', 'clipforge')[:80]}.mp4",
        background=None,
    )


@app.get("/api/import/{file_id}/meta")
def imported_video_meta(file_id: str):
    _cleanup_expired_imports()
    meta = _url_imports.get(file_id)
    if not meta:
        raise HTTPException(status_code=404, detail="File not found or expired")
    return {
        "file_id": file_id,
        "title": meta["title"],
        "duration_seconds": meta["duration"],
        "size_bytes": meta["size"],
        "expires_in_seconds": max(0, int(meta["expires_at"] - time.time())),
    }
