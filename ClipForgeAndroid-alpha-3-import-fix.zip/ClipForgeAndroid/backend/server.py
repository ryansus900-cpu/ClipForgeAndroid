"""Development transcription backend for ClipForge. Deploy behind authentication/rate limits."""
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from openai import OpenAI

app = FastAPI(title="ClipForge STT Backend", version="0.1.0")
client = OpenAI()

MAX_UPLOAD_MB = int(os.getenv("CLIPFORGE_MAX_UPLOAD_MB", "800"))
MAX_SEGMENT_SECONDS = int(os.getenv("CLIPFORGE_AUDIO_SEGMENT_SECONDS", "600"))

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/transcribe")
def transcribe(video: UploadFile = File(...), language: str = Form("auto")):
    """Upload video, extract mono 32-kbps MP3, split into 10-min chunks, transcribe word timings."""
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    with tempfile.TemporaryDirectory(prefix="clipforge-stt-") as tmp:
        root = Path(tmp)
        video_path = root / "source_video"
        size = 0
        with video_path.open("wb") as f:
            while chunk := video.file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        audio_path = root / "audio.mp3"
        try:
            subprocess.run([
                "ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1", "-ar", "16000",
                "-b:a", "32k", str(audio_path)
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=900)
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            raise HTTPException(status_code=422, detail="Audio extraction failed. Check ffmpeg and file validity.") from e

        # Split to keep each API request below its audio upload limit and support long videos.
        chunks = root / "chunk-%03d.mp3"
        try:
            subprocess.run([
                "ffmpeg", "-y", "-i", str(audio_path), "-f", "segment", "-segment_time",
                str(MAX_SEGMENT_SECONDS), "-c", "copy", str(chunks)
            ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=900)
        except subprocess.CalledProcessError as e:
            raise HTTPException(status_code=422, detail="Audio segmentation failed") from e

        word_results = []
        detected = "unknown"
        offset = 0.0
        for chunk_file in sorted(root.glob("chunk-*.mp3")):
            if chunk_file.stat().st_size > 24 * 1024 * 1024:
                raise HTTPException(status_code=413, detail="Audio chunk is still over 24 MB; reduce segment size or bitrate")
            with chunk_file.open("rb") as audio:
                kwargs = dict(file=audio, model="whisper-1", response_format="verbose_json", timestamp_granularities=["word"])
                if language and language.lower() != "auto":
                    kwargs["language"] = language
                result = client.audio.transcriptions.create(**kwargs)
            detected = getattr(result, "language", detected) or detected
            for word in (getattr(result, "words", None) or []):
                word_results.append({
                    "text": word.word,
                    "start": float(word.start) + offset,
                    "end": float(word.end) + offset,
                })
            # Get actual segment duration to avoid accumulated offset drift for short final chunks.
            try:
                duration = float(subprocess.check_output([
                    "ffprobe", "-v", "error", "-show_entries", "format=duration",
                    "-of", "default=noprint_wrappers=1:nokey=1", str(chunk_file)
                ], text=True).strip())
            except (subprocess.CalledProcessError, ValueError, FileNotFoundError):
                duration = MAX_SEGMENT_SECONDS
            offset += duration

        return {"detected_language": detected, "words": word_results}

@app.post("/api/audio/analyze")
def analyze_audio(video: UploadFile = File(...), words_json: str = Form("[]")):
    """Stream-decode uploaded video audio and return energy/silence features."""
    import json
    from audio_intelligence import analyze_pcm16_mono, estimate_pace_from_words
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    try:
        words = json.loads(words_json)
        if not isinstance(words, list):
            raise ValueError("words_json must be a list")
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="Invalid words_json")
    with tempfile.TemporaryDirectory(prefix="clipforge-audio-") as tmp:
        video_path = Path(tmp) / "source_video"
        size = 0
        with video_path.open("wb") as f:
            while chunk := video.file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_MB * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        command = ["ffmpeg", "-v", "error", "-i", str(video_path), "-vn", "-ac", "1",
                   "-ar", "16000", "-f", "s16le", "pipe:1"]
        try:
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            def stream_chunks():
                assert proc.stdout is not None
                while True:
                    data = proc.stdout.read(32000)  # one second of 16-kHz mono PCM
                    if not data:
                        break
                    yield data
            result = analyze_pcm16_mono(stream_chunks(), sample_rate=16000, window_seconds=0.5)
            _, stderr = proc.communicate(timeout=900)
            if proc.returncode != 0:
                raise HTTPException(status_code=422, detail="Audio decoding failed")
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            if 'proc' in locals() and proc.poll() is None:
                proc.kill()
            raise HTTPException(status_code=422, detail="FFmpeg audio analysis failed") from exc
    result["speech_pace_wpm"] = estimate_pace_from_words(words, result["duration_seconds"])
    result["analysis_version"] = "audio_signal_v1"
    return result


@app.post("/api/clips/analyze")
def analyze_clips(payload: dict):
    """Rank timestamped transcript clip candidates; audio_features are optional summaries."""
    from clip_analysis import analyze_transcript
    from audio_clip_scoring import score_candidates_with_audio
    words = payload.get("words", [])
    if not isinstance(words, list):
        raise HTTPException(status_code=422, detail="words must be a JSON array")
    try:
        clip_count = int(payload.get("clip_count", 8))
    except (ValueError, TypeError):
        raise HTTPException(status_code=422, detail="clip_count must be an integer")
    clip_count = max(1, min(10, clip_count))
    prompt = str(payload.get("prompt", ""))[:500]
    clips = analyze_transcript(words, clip_count=clip_count, prompt=prompt)
    audio_features = payload.get("audio_features")
    clips = score_candidates_with_audio(clips, audio_features)
    return {"clips": clips, "scoring_mode": "transcript_plus_audio" if audio_features else "transcript_only",
            "note": "Heuristic ranking; scores are estimates, not guaranteed virality."}

@app.post("/api/audio/cleanup/analyze")
def analyze_cleanup(video: UploadFile = File(...), words_json: str = Form("[]")):
    """Return audio silence, transcript filler, pace, and non-destructive cut suggestions."""
    import json
    from audio_intelligence import analyze_pcm16_mono
    from speech_cleanup import detect_fillers, speech_pace, propose_cleanup
    if not video.content_type or not video.content_type.startswith("video/"):
        raise HTTPException(status_code=415, detail="A video file is required")
    try:
        words=json.loads(words_json)
        if not isinstance(words,list): raise ValueError("words must be list")
    except (ValueError,TypeError):
        raise HTTPException(status_code=422, detail="Invalid words_json")
    with tempfile.TemporaryDirectory(prefix="clipforge-cleanup-") as tmp:
        video_path=Path(tmp)/"source_video"
        size=0
        with video_path.open("wb") as f:
            while chunk:=video.file.read(1024*1024):
                size+=len(chunk)
                if size>MAX_UPLOAD_MB*1024*1024:
                    raise HTTPException(status_code=413, detail="Video exceeds configured upload size limit")
                f.write(chunk)
        command=["ffmpeg","-v","error","-i",str(video_path),"-vn","-ac","1","-ar","16000","-f","s16le","pipe:1"]
        try:
            proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            def chunks():
                assert proc.stdout is not None
                while True:
                    data=proc.stdout.read(32000)
                    if not data: break
                    yield data
            audio=analyze_pcm16_mono(chunks(),sample_rate=16000,window_seconds=.5)
            _,err=proc.communicate(timeout=900)
            if proc.returncode:
                raise HTTPException(status_code=422,detail="Audio decoding failed")
        except (FileNotFoundError,subprocess.TimeoutExpired) as exc:
            if 'proc' in locals() and proc.poll() is None: proc.kill()
            raise HTTPException(status_code=422,detail="FFmpeg cleanup analysis failed") from exc
    fillers=detect_fillers(words)
    pace=speech_pace(words)
    suggestions=propose_cleanup(words,audio.get("silence_segments",[]))
    return {"analysis_version":"speech_cleanup_v1", "audio":audio, "fillers":fillers,
            "pace":pace, "cut_suggestions":suggestions,
            "note":"Suggestions are non-destructive and require user review. Filler detection is lexical and may misclassify words used meaningfully."}
