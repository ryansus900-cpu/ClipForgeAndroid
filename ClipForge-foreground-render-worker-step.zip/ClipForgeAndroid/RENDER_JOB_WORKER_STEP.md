# RenderJobWorker integration step

Added `RenderJobWorker`, which submits a video and selected clip ranges to `/api/clips/render`, polls `/api/jobs/{job_id}`, records progress in Room, and downloads the completed ZIP to app-private storage.

## Enqueue from Android code

```kotlin
RenderJobWorker.enqueue(
    context = context,
    videoUri = selectedVideoUri,
    clipsJson = clipsJson, // each item: {"start_seconds": 12.0, "end_seconds": 40.0}
    backendUrl = configuredBackendBaseUrl
)
```

## Limitations / next integration

- The current app UI is not wired to this enqueue method yet.
- Backend job IDs are persisted in the Room record to allow WorkManager retry recovery.
- Completed ZIP is saved under app-private files (`filesDir/render_<local-job-id>.zip`). A results UI / share action still needs to expose it.
- The API currently stores job status in backend memory; backend restarts may lose status.
- This patch has not been built with Android Gradle or tested against a deployed backend. Validate with a small sample video before release.
