# Render UI Integration (step package)

This step adds the render-job worker to the main app UI flow.

- The suggested-clips screen supports selecting clips for batch rendering (up to 10).
- Backend URL is editable in the screen and stored in app SharedPreferences (`clipforge` / `backend_url`).
- A button queues `RenderJobWorker` with the selected clip timestamps and video URI.
- Render-job rows observe Room and display status, clip counters, and progress.

This source package has not been compiled or run on-device. The backend API must be deployed and reachable; the URL field must be configured. The backend job state is currently memory-based, so server restarts can lose job status.
