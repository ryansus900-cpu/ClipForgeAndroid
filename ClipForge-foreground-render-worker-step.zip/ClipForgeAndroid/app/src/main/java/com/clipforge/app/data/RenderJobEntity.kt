package com.clipforge.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Persistent record of a clip-render job. Status strings are intentionally simple for API mapping. */
@Entity(tableName = "render_jobs")
data class RenderJobEntity(
    @PrimaryKey val jobId: String,
    val backendUrl: String,
    val status: String = "QUEUED",
    val progress: Int = 0,
    val totalClips: Int = 0,
    val completedClips: Int = 0,
    val downloadUrl: String = "",
    val errorMessage: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
