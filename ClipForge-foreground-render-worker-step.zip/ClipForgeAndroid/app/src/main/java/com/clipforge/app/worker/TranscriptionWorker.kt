package com.clipforge.app.worker

import android.content.Context
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.pm.ServiceInfo
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.ForegroundInfo
import androidx.core.app.NotificationCompat
import androidx.room.Room
import com.clipforge.app.BuildConfig
import com.clipforge.app.data.BackendTranscriptionProvider
import com.clipforge.app.data.ClipForgeDatabase
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Uploads the user's selected video by stream to the configured backend and saves timestamped words. */
class TranscriptionWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        setForeground(makeForegroundInfo())
        return withContext(Dispatchers.IO) {
        val uri = inputData.getString(KEY_URI).orEmpty()
        if (uri.isBlank()) return@withContext Result.failure()
        val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7, ClipForgeDatabase.MIGRATION_7_8).build()
        try {
            val project = db.projectDao().findByUri(uri) ?: return@withContext Result.retry()
            db.projectDao().saveTranscript(project.id, "", "", "processing")
            val result = BackendTranscriptionProvider(applicationContext, BuildConfig.CLIPFORGE_API_BASE)
                .transcribe(uri, inputData.getString(KEY_LANGUAGE) ?: "auto")
            val jsonWords = JSONArray()
            result.words.forEach { w ->
                jsonWords.put(JSONObject().put("text", w.text).put("start", w.startSeconds).put("end", w.endSeconds))
            }
            val transcriptJson = JSONObject().put("words", jsonWords).toString()
            db.projectDao().saveTranscript(project.id, result.detectedLanguage, transcriptJson, "complete")
            Result.success()
        } catch (e: IllegalArgumentException) {
            val project = db.projectDao().findByUri(uri)
            if (project != null) db.projectDao().saveTranscript(project.id, "", "", "error: ${e.message ?: "configuration error"}")
            Result.failure()
        } catch (e: Exception) {
            val project = db.projectDao().findByUri(uri)
            if (project != null) db.projectDao().saveTranscript(project.id, "", "", "error: ${e.message ?: "transcription failed"}")
            Result.retry()
        } finally { db.close() }
        }
    }

    private fun makeForegroundInfo(): ForegroundInfo {
        val channelId = "clipforge_transcription"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "ClipForge transcription", NotificationManager.IMPORTANCE_LOW)
            applicationContext.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(applicationContext, channelId)
            .setContentTitle("ClipForge")
            .setContentText("Transcribing video · word timestamps")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(501, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else ForegroundInfo(501, notification)
    }

    companion object {
        const val KEY_URI = "transcription_video_uri"
        const val KEY_LANGUAGE = "transcription_language"
    }
}
