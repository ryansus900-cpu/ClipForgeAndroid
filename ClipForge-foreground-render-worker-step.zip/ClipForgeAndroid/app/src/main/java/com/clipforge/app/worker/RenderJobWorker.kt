package com.clipforge.app.worker

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import androidx.work.Data
import androidx.work.ForegroundInfo
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.room.Room
import com.clipforge.app.data.ClipForgeDatabase
import com.clipforge.app.data.RenderJobEntity
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Uploads selected clips to the backend, polls status, then downloads the finished ZIP. */
class RenderJobWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    companion object {
        const val KEY_VIDEO_URI = "video_uri"
        const val KEY_CLIPS_JSON = "clips_json"
        const val KEY_BACKEND_URL = "backend_url"
        const val KEY_LOCAL_JOB_ID = "local_job_id"
        const val KEY_RESULT_PATH = "result_path"
        const val KEY_REMOTE_JOB_ID = "remote_job_id"
        private const val POLL_INTERVAL_MS = 3000L
        private const val MAX_POLL_MINUTES = 180

        fun enqueue(context: Context, videoUri: Uri, clipsJson: String, backendUrl: String): UUID {
            val request = OneTimeWorkRequestBuilder<RenderJobWorker>()
                .setInputData(workDataOf(KEY_VIDEO_URI to videoUri.toString(), KEY_CLIPS_JSON to clipsJson,
                    KEY_BACKEND_URL to backendUrl.trim().trimEnd('/'), KEY_LOCAL_JOB_ID to UUID.randomUUID().toString()))
                .build()
            WorkManager.getInstance(context).enqueue(request)
            return request.id
        }
    }

    private val db by lazy {
        Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3,
                ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5,
                ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7,
                ClipForgeDatabase.MIGRATION_7_8).build()
    }

    override suspend fun doWork(): Result {
        val videoUri = inputData.getString(KEY_VIDEO_URI) ?: return Result.failure()
        val clipsJson = inputData.getString(KEY_CLIPS_JSON) ?: return Result.failure()
        val baseUrl = inputData.getString(KEY_BACKEND_URL)?.trim()?.trimEnd('/')?.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            ?: return Result.failure(workDataOf("error" to "Set a valid backend URL first"))
        val localId = inputData.getString(KEY_LOCAL_JOB_ID) ?: id.toString()
        val dao = db.renderJobDao()
        var remoteId = inputData.getString(KEY_REMOTE_JOB_ID).orEmpty()
        if (remoteId.isBlank()) {
            // Recover the server job ID from Room if WorkManager retries this worker.
            val previous = dao.get(localId)
            val marker = "Remote job: "
            if (previous?.errorMessage?.startsWith(marker) == true) remoteId = previous.errorMessage.removePrefix(marker).trim()
        }
        val clips = try { JSONArray(clipsJson) } catch (_: Exception) { return Result.failure(workDataOf("error" to "Invalid clip list")) }
        try {
            ensureForeground("Uploading video…", 0)
            if (remoteId.isBlank()) {
                setProgress(workDataOf("status" to "UPLOADING", "progress" to 0))
                dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "UPLOADING", totalClips = clips.length()))
                remoteId = submit(baseUrl, videoUri, clipsJson)
                dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "QUEUED", totalClips = clips.length(), errorMessage = "Remote job: $remoteId"))
            }
            var elapsed = 0L
            while (elapsed < MAX_POLL_MINUTES * 60_000L) {
                val snapshot = poll(baseUrl, remoteId)
                val status = snapshot.optString("status", "UNKNOWN").uppercase()
                val progress = snapshot.optInt("progress", 0).coerceIn(0, 100)
                val completed = snapshot.optInt("completed_clips", 0)
                val total = snapshot.optInt("total_clips", clips.length())
                val err = snapshot.optString("error_message", "")
                dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = status, progress = progress,
                    totalClips = total, completedClips = completed, downloadUrl = if (status == "COMPLETED") "/api/jobs/$remoteId/download" else "", errorMessage = err))
                updateForeground("Rendering clips: $completed/$total", progress)
                setProgress(workDataOf("status" to status, "progress" to progress, "completed_clips" to completed,
                    "total_clips" to total, KEY_REMOTE_JOB_ID to remoteId))
                when (status) {
                    "COMPLETED" -> {
                        val target = File(applicationContext.filesDir, "render_${localId}.zip")
                        download(baseUrl, "/api/jobs/$remoteId/download", target)
                        dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "COMPLETED", progress = 100,
                            totalClips = total, completedClips = total, downloadUrl = target.absolutePath, errorMessage = ""))
                        return Result.success(workDataOf(KEY_RESULT_PATH to target.absolutePath, KEY_REMOTE_JOB_ID to remoteId))
                    }
                    "FAILED" -> {
                        dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "FAILED", progress = progress,
                            totalClips = total, completedClips = completed, errorMessage = err.ifBlank { "Render failed on server" }))
                        return Result.failure(workDataOf("error" to err, KEY_REMOTE_JOB_ID to remoteId))
                    }
                }
                delay(POLL_INTERVAL_MS)
                elapsed += POLL_INTERVAL_MS
            }
            dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "TIMEOUT", progress = 0,
                totalClips = clips.length(), errorMessage = "Timed out waiting for server; remote job ID: $remoteId"))
            return Result.failure(workDataOf("error" to "Polling timed out", KEY_REMOTE_JOB_ID to remoteId))
        } catch (e: Exception) {
            val msg = e.message ?: e.javaClass.simpleName
            dao.upsert(RenderJobEntity(jobId = localId, backendUrl = baseUrl, status = "FAILED", progress = 0,
                totalClips = clips.length(), errorMessage = msg.take(800)))
            return if (remoteId.isNotBlank()) Result.retry() else Result.failure(workDataOf("error" to msg))
        }
    }

    private fun ensureForeground(message: String, progress: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("clipforge_render", "ClipForge rendering", NotificationManager.IMPORTANCE_LOW)
            manager.createNotificationChannel(channel)
        }
        val notification = buildNotification(message, progress)
        val foregroundInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(9107, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else ForegroundInfo(9107, notification)
        setForeground(foregroundInfo)
    }

    private fun updateForeground(message: String, progress: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(9107, buildNotification(message, progress))
    }

    private fun buildNotification(message: String, progress: Int): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(applicationContext, "clipforge_render")
        } else Notification.Builder(applicationContext)
        builder.setContentTitle("ClipForge")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        if (progress in 1..99) builder.setProgress(100, progress, false)
        else if (progress >= 100) builder.setProgress(100, 100, false)
        else builder.setProgress(0, 0, true)
        return builder.build()
    }

    private fun submit(base: String, uriText: String, clipsJson: String): String {
        val boundary = "----ClipForge${UUID.randomUUID()}"
        val conn = (URL("$base/api/clips/render").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; doOutput = true; connectTimeout = 30000; readTimeout = 120000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        conn.outputStream.use { out ->
            fun field(name: String, value: String) {
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("clips_json", clipsJson)
            val uri = Uri.parse(uriText)
            val name = "video.mp4"
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"video\"; filename=\"$name\"\r\nContent-Type: video/mp4\r\n\r\n".toByteArray())
            applicationContext.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) { val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n) }
            } ?: throw IllegalStateException("Unable to open selected video")
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Render upload failed ($code): ${body.take(300)}")
        return JSONObject(body).getString("job_id")
    }

    private fun poll(base: String, jobId: String): JSONObject = requestJson("$base/api/jobs/$jobId")

    private fun requestJson(url: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 20000; readTimeout = 30000 }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (code !in 200..299) throw IllegalStateException("Backend request failed ($code): ${body.take(300)}")
        return JSONObject(body)
    }

    private fun download(base: String, path: String, target: File) {
        val conn = (URL(base + path).openConnection() as HttpURLConnection).apply { connectTimeout = 20000; readTimeout = 120000 }
        val code = conn.responseCode
        if (code !in 200..299) { conn.disconnect(); throw IllegalStateException("ZIP download failed ($code)") }
        target.outputStream().buffered().use { out -> conn.inputStream.buffered().use { it.copyTo(out) } }
        conn.disconnect()
    }
}
