package com.clipforge.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RenderJobDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(job: RenderJobEntity)

    @Query("SELECT * FROM render_jobs ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<RenderJobEntity>>

    @Query("SELECT * FROM render_jobs WHERE jobId = :jobId LIMIT 1")
    suspend fun get(jobId: String): RenderJobEntity?

    @Query("UPDATE render_jobs SET status = :status, progress = :progress, completedClips = :completedClips, totalClips = :totalClips, downloadUrl = :downloadUrl, errorMessage = :errorMessage, updatedAt = :updatedAt WHERE jobId = :jobId")
    suspend fun updateProgress(jobId: String, status: String, progress: Int, completedClips: Int, totalClips: Int, downloadUrl: String, errorMessage: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM render_jobs WHERE jobId = :jobId")
    suspend fun delete(jobId: String)
}
