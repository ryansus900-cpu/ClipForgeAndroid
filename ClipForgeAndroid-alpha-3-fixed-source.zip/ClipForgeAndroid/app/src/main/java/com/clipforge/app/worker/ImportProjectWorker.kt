package com.clipforge.app.worker

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.room.Room
import com.clipforge.app.data.ClipForgeDatabase
import com.clipforge.app.data.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Imports a video into the local project catalog. Media is inspected through a URI, never loaded into RAM. */
class ImportProjectWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val rawUri = inputData.getString(KEY_URI) ?: return@withContext Result.failure()
        val uri = runCatching { Uri.parse(rawUri) }.getOrNull() ?: return@withContext Result.failure()
        if (rawUri.isBlank()) return@withContext Result.failure()

        val retriever = MediaMetadataRetriever()
        val metadata = try {
            retriever.setDataSource(applicationContext, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            Triple(durationMs, width, height)
        } catch (_: Exception) {
            return@withContext Result.failure()
        } finally {
            runCatching { retriever.release() }
        }

        val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6).build()
        try {
            val name = inputData.getString(KEY_NAME)?.takeIf { it.isNotBlank() } ?: "Video project"
            db.projectDao().insert(ProjectEntity(
                name = name,
                sourceUri = rawUri,
                sourceType = "file",
                status = "imported",
                durationMs = metadata.first,
                videoWidth = metadata.second,
                videoHeight = metadata.third
            ))
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        } finally {
            db.close()
        }
    }

    companion object {
        const val KEY_URI = "video_uri"
        const val KEY_NAME = "display_name"
    }
}
