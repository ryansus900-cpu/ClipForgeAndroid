package com.clipforge.app.worker

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.room.Room
import com.clipforge.app.data.ClipForgeDatabase
import com.clipforge.app.data.ProjectEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Imports a video into the local project catalog. Media is inspected through a URI, never loaded into RAM. */
class ImportProjectWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val rawUri = inputData.getString(KEY_URI)
            ?: return@withContext failure("Import failed: video URI was missing.")
        if (rawUri.isBlank()) return@withContext failure("Import failed: selected video URI was empty.")
        val uri = runCatching { Uri.parse(rawUri) }.getOrElse {
            return@withContext failure("Import failed: selected video URI is invalid.")
        }

        setProgress(androidx.work.workDataOf(KEY_STAGE to "Inspecting video metadata"))
        val retriever = MediaMetadataRetriever()
        val metadata = try {
            retriever.setDataSource(applicationContext, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            if (durationMs <= 0L || width <= 0 || height <= 0) {
                return@withContext failure("Import failed: video metadata was incomplete. Try choosing the video again.")
            }
            Triple(durationMs, width, height)
        } catch (e: Exception) {
            return@withContext failure("Import failed while reading video: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            runCatching { retriever.release() }
        }

        val db = Room.databaseBuilder(applicationContext, ClipForgeDatabase::class.java, "clipforge.db")
            .addMigrations(ClipForgeDatabase.MIGRATION_1_2, ClipForgeDatabase.MIGRATION_2_3, ClipForgeDatabase.MIGRATION_3_4, ClipForgeDatabase.MIGRATION_4_5, ClipForgeDatabase.MIGRATION_5_6, ClipForgeDatabase.MIGRATION_6_7, ClipForgeDatabase.MIGRATION_7_8).build()
        try {
            setProgress(androidx.work.workDataOf(KEY_STAGE to "Saving project"))
            val name = inputData.getString(KEY_NAME)?.takeIf { it.isNotBlank() } ?: "Video project"
            val existing = db.projectDao().findByUri(rawUri)
            if (existing != null) {
                return@withContext Result.success(androidx.work.workDataOf(KEY_MESSAGE to "Project already imported. Open it to continue."))
            }
            db.projectDao().insert(ProjectEntity(
                name = name,
                sourceUri = rawUri,
                sourceType = "file",
                status = "imported",
                durationMs = metadata.first,
                videoWidth = metadata.second,
                videoHeight = metadata.third
            ))
            Result.success(androidx.work.workDataOf(KEY_MESSAGE to "Import complete. Project saved."))
        } catch (e: Exception) {
            failure("Import failed while saving project: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            db.close()
        }
    }

    private fun failure(message: String): Result = Result.failure(androidx.work.workDataOf(KEY_ERROR to message))

    companion object {
        const val KEY_URI = "video_uri"
        const val KEY_NAME = "display_name"
        const val KEY_STAGE = "import_stage"
        const val KEY_MESSAGE = "import_message"
        const val KEY_ERROR = "import_error"
    }
}
