package com.clipforge.app

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private data class CaptionWord(val text: String, val start: Double, val end: Double)
private enum class CaptionPreset(val label: String) { BOLD_YELLOW("Bold Yellow"), MINIMAL("Minimal"), KARAOKE("Karaoke"), NEON("Neon"), POP("Pop-in"), HORMOZI("Bold Punch") }
private enum class CaptionAnimation(val label: String) { NONE("None"), POP("Pop"), BOUNCE("Bounce"), FADE("Fade"), SLIDE_UP("Slide Up") }
private data class CaptionColor(val label: String, val hex: String, val color: Color)
private val captionColors = listOf(
    CaptionColor("Yellow", "#FFFFE45E", Color(0xFFFFE45E)), CaptionColor("White", "#FFFFFFFF", Color.White),
    CaptionColor("Cyan", "#FF65F5FA", Color(0xFF65F5FA)), CaptionColor("Pink", "#FFFF77B7", Color(0xFFFF77B7)),
    CaptionColor("Green", "#FF90EE90", Color(0xFF90EE90)), CaptionColor("Orange", "#FFFFA64D", Color(0xFFFFA64D))
)

@Composable
fun SubtitleStudio(transcriptJson: String, language: String, savedSettingsJson: String = "", onSave: (String, String) -> Unit, onClose: () -> Unit) {
    val originalWords = remember(transcriptJson) { parseCaptionWords(transcriptJson) }
    var editedText by remember(transcriptJson) { mutableStateOf(originalWords.joinToString(" ") { it.text }) }
    val savedStyle = remember(savedSettingsJson) { runCatching { JSONObject(savedSettingsJson) }.getOrNull() }
    var preset by remember(savedSettingsJson) { mutableStateOf(CaptionPreset.entries.firstOrNull { it.name == savedStyle?.optString("preset") } ?: CaptionPreset.BOLD_YELLOW) }
    var fontSize by remember(savedSettingsJson) { mutableFloatStateOf(savedStyle?.optInt("size", 25)?.toFloat()?.coerceIn(16f, 40f) ?: 25f) }
    var position by remember(savedSettingsJson) { mutableStateOf(savedStyle?.optString("position", "Bottom") ?: "Bottom") }
    var colorHex by remember(savedSettingsJson) { mutableStateOf(savedStyle?.optString("customColor", "") ?: "") }
    var animation by remember(savedSettingsJson) { mutableStateOf(CaptionAnimation.entries.firstOrNull { it.name == savedStyle?.optString("animation", "NONE") } ?: CaptionAnimation.NONE) }
    var selectedWord by remember(transcriptJson) { mutableIntStateOf(0) }
    var previewTime by remember(transcriptJson) { mutableFloatStateOf(originalWords.firstOrNull()?.start?.toFloat() ?: 0f) }
    var wordEdit by remember(transcriptJson) { mutableStateOf(originalWords.firstOrNull()?.text.orEmpty()) }
    var startEdit by remember(transcriptJson) { mutableFloatStateOf(originalWords.firstOrNull()?.start?.toFloat() ?: 0f) }
    var endEdit by remember(transcriptJson) { mutableFloatStateOf(originalWords.firstOrNull()?.end?.toFloat() ?: 0f) }
    var saved by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var brandText by remember(savedSettingsJson) { mutableStateOf(savedStyle?.optString("brandText", "") ?: "") }
    var presetName by remember { mutableStateOf("") }
    var brandPresets by remember { mutableStateOf(CaptionBrandKitStore.load(context)) }
    val totalDuration = (originalWords.lastOrNull()?.end ?: 1.0).toFloat().coerceAtLeast(0.1f)
    val chosenColor = captionColors.firstOrNull { it.hex == colorHex }?.color ?: when (preset) {
        CaptionPreset.BOLD_YELLOW, CaptionPreset.HORMOZI -> Color(0xFFFFE45E)
        CaptionPreset.NEON -> Color(0xFF65F5FA)
        else -> Color.White
    }
    val previewText = editedText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(9).joinToString(" ")
    val editedTokens = editedText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    val previewWords = originalWords.mapIndexed { i, word ->
        word.copy(text = editedTokens.getOrNull(i) ?: word.text,
            start = if (i == selectedWord) startEdit.toDouble() else word.start,
            end = if (i == selectedWord) endEdit.toDouble() else word.end)
    }
    val activePreviewWord = previewWords.indexOfFirst { previewTime >= it.start && previewTime <= it.end }
    val previewChunkStart = if (activePreviewWord >= 0) (activePreviewWord / 5) * 5 else -1
    val timedPreviewText = if (previewChunkStart >= 0) previewWords.drop(previewChunkStart).take(5).joinToString(" ") { it.text } else ""
    val activePreviewText = previewWords.getOrNull(activePreviewWord)?.text.orEmpty()
    fun loadSelected(index: Int) {
        val word = originalWords.getOrNull(index) ?: return
        selectedWord = index
        wordEdit = word.text
        startEdit = word.start.toFloat().coerceIn(0f, totalDuration)
        endEdit = word.end.toFloat().coerceIn(startEdit, totalDuration)
        previewTime = word.start.toFloat().coerceIn(0f, totalDuration)
    }
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B12)).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("SUBTITLE STUDIO", color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            TextButton(onClick = onClose) { Text("Close") }
        }
        Text("Language detected: ${language.ifBlank { "Unknown" }} · Edit captions and timing", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF252333)), shape = RoundedCornerShape(18.dp)) {
            Box(Modifier.fillMaxWidth().height(220.dp).padding(12.dp), contentAlignment = when(position) { "Top" -> Alignment.TopCenter; "Middle" -> Alignment.Center; else -> Alignment.BottomCenter }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(timedPreviewText.ifBlank { if (originalWords.isEmpty()) previewText.ifBlank { "Your captions preview here" } else "No caption at this timestamp" }, color = chosenColor, fontSize = fontSize.sp, fontWeight = if (preset == CaptionPreset.MINIMAL) FontWeight.Medium else FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().graphicsLayer { val intro = ((previewTime - (previewWords.getOrNull(activePreviewWord)?.start?.toFloat() ?: previewTime)) / 0.22f).coerceIn(0f, 1f); alpha = if (animation == CaptionAnimation.FADE) intro else 1f; scaleX = when (animation) { CaptionAnimation.POP -> 0.78f + 0.22f * intro; CaptionAnimation.BOUNCE -> if (intro < 0.65f) 0.75f + 0.37f * (intro / 0.65f) else 1.12f - 0.12f * ((intro - 0.65f) / 0.35f); else -> 1f }; scaleY = scaleX; translationY = if (animation == CaptionAnimation.SLIDE_UP) 35f * (1f - intro) else 0f }.background(if (preset == CaptionPreset.NEON) Color(0x5520DDE8) else Color.Transparent, RoundedCornerShape(6.dp)).padding(6.dp))
                    if (activePreviewText.isNotBlank()) Text("Preview highlight: $activePreviewText", color = Color(0xFFFFE45E), style = MaterialTheme.typography.labelSmall)
                    if (brandText.isNotBlank()) Text(brandText, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, modifier = Modifier.align(Alignment.End).padding(top = 6.dp))
                }
            }
        }
        if (originalWords.isNotEmpty()) {
            Text("CAPTION TIMING PREVIEW · ${previewTime.toString().take(5)}s / ${totalDuration.toString().take(5)}s", color = Color(0xFFB7B3C4), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 8.dp))
            Slider(value = previewTime.coerceIn(0f, totalDuration), onValueChange = { previewTime = it }, valueRange = 0f..totalDuration)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Start", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.labelSmall)
                Text("${activePreviewText.ifBlank { "—" }}", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.labelSmall)
                Text("End", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.labelSmall)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("MY BRAND KIT", color = Color.White, style = MaterialTheme.typography.labelLarge)
        if (brandPresets.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                brandPresets.forEach { savedPreset ->
                    val name = savedPreset.optString("name")
                    FilterChip(selected = false, onClick = {
                        val st = savedPreset.optJSONObject("style") ?: JSONObject()
                        preset = CaptionPreset.entries.firstOrNull { it.name == st.optString("preset") } ?: CaptionPreset.BOLD_YELLOW
                        fontSize = st.optInt("size", 25).toFloat().coerceIn(16f, 40f)
                        position = st.optString("position", "Bottom")
                        colorHex = st.optString("customColor", "")
                        animation = CaptionAnimation.entries.firstOrNull { it.name == st.optString("animation", "NONE") } ?: CaptionAnimation.NONE
                        brandText = st.optString("brandText", "")
                        saved = false
                    }, label = { Text(name) })
                }
            }
        } else Text("Save a custom caption look to reuse it on other projects.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(value = presetName, onValueChange = { presetName = it.take(32) }, modifier = Modifier.fillMaxWidth(), label = { Text("Preset name") }, singleLine = true)
        OutlinedTextField(value = brandText, onValueChange = { brandText = it.take(40); saved = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Brand / watermark text (optional)") }, singleLine = true, placeholder = { Text("e.g. MindWeave") })
        OutlinedButton(onClick = {
            val style = JSONObject().put("preset", preset.name).put("size", fontSize.toInt()).put("position", position).put("customColor", colorHex).put("animation", animation.name).put("brandText", brandText).put("version", 4)
            CaptionBrandKitStore.save(context, presetName, style)
            brandPresets = CaptionBrandKitStore.load(context)
            presetName = ""
        }, enabled = presetName.trim().isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Save current look to Brand Kit") }
        Text("STYLE PRESETS", color = Color.White, style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CaptionPreset.entries.forEach { item -> FilterChip(selected = preset == item, onClick = { preset = item; if (item == CaptionPreset.NEON) colorHex = "#FF65F5FA" else if (colorHex.isNotBlank()) colorHex = ""; saved = false }, label = { Text(item.label) }) }
        }
        Text("Caption color", color = Color.White, modifier = Modifier.padding(top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            captionColors.forEach { swatch ->
                FilterChip(selected = colorHex == swatch.hex, onClick = { colorHex = swatch.hex; saved = false }, label = { Text(swatch.label) })
            }
        }
        Text("Caption size · ${fontSize.toInt()} sp", color = Color.White)
        Slider(value = fontSize, onValueChange = { fontSize = it; saved = false }, valueRange = 16f..40f)
        Text("Position", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Top", "Middle", "Bottom").forEach { p -> FilterChip(selected = position == p, onClick = { position = p; saved = false }, label = { Text(p) }) } }
        Text("CAPTION ANIMATION", color = Color.White, modifier = Modifier.padding(top = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            CaptionAnimation.entries.forEach { effect ->
                FilterChip(selected = animation == effect, onClick = { animation = effect; saved = false }, label = { Text(effect.label) })
            }
        }
        Text("Effects preview in the style card and are rendered into exports.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(14.dp))
        Text("WORD TIMING EDITOR", color = Color.White, style = MaterialTheme.typography.labelLarge)
        if (originalWords.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                originalWords.forEachIndexed { i, word -> FilterChip(selected = i == selectedWord, onClick = { loadSelected(i) }, label = { Text("${i + 1}: ${word.text}") }) }
            }
            OutlinedTextField(value = wordEdit, onValueChange = { wordEdit = it; saved = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Selected word caption") }, singleLine = true)
            Text("Start · ${startEdit.toString().take(5)}s", color = Color.White)
            Slider(value = startEdit.coerceIn(0f, (endEdit - 0.02f).coerceAtLeast(0f)), onValueChange = { startEdit = it.coerceIn(0f, (endEdit - 0.02f).coerceAtLeast(0f)); previewTime = startEdit; saved = false }, valueRange = 0f..(totalDuration - 0.02f).coerceAtLeast(0.02f))
            Text("End · ${endEdit.toString().take(5)}s", color = Color.White)
            Slider(value = endEdit.coerceIn((startEdit + 0.02f).coerceAtMost(totalDuration), totalDuration), onValueChange = { endEdit = it.coerceIn((startEdit + 0.02f).coerceAtMost(totalDuration), totalDuration); previewTime = endEdit; saved = false }, valueRange = (startEdit + 0.02f).coerceAtMost(totalDuration)..totalDuration)
            Text("Timing changes apply to the selected word. Move the preview slider above to inspect when the caption appears. Saved timings are retained for export.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
        } else Text("No word-level timestamps found. Transcribe the video to enable timing controls.", color = Color(0xFFAAA6B8))
        Spacer(Modifier.height(12.dp))
        Text("EDIT FULL TRANSCRIPT", color = Color.White, style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(value = editedText, onValueChange = { editedText = it; saved = false }, modifier = Modifier.fillMaxWidth(), minLines = 4, maxLines = 8, placeholder = { Text("Edit recognized speech…") })
        Text("If word count remains the same, existing timestamps are kept (including edited word timing). If word count changes, timings are estimated evenly across the original transcript span.", color = Color(0xFFAAA6B8), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {
            val revisedWords = originalWords.mapIndexed { i, word -> if (i == selectedWord) word.copy(text = wordEdit.trim().ifBlank { word.text }, start = startEdit.toDouble(), end = endEdit.toDouble()) else word }
            val textTokens = editedText.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.toMutableList()
            if (textTokens.size == revisedWords.size && selectedWord in textTokens.indices) textTokens[selectedWord] = wordEdit.trim().ifBlank { textTokens[selectedWord] }
            val finalTranscriptText = textTokens.joinToString(" ")
            val newTranscript = rebuildCaptionJson(revisedWords, finalTranscriptText)
            val style = JSONObject().put("preset", preset.name).put("size", fontSize.toInt()).put("position", position).put("customColor", colorHex).put("animation", animation.name).put("brandText", brandText).put("version", 4).toString()
            onSave(newTranscript, style); saved = true
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Save transcript, timing & style") }
        if (saved) Text("Saved locally to project transcript and caption settings.", color = Color(0xFF8CE6A6), modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(12.dp))
    }
}

private fun parseCaptionWords(json: String): List<CaptionWord> = runCatching {
    val arr = JSONObject(json).optJSONArray("words") ?: JSONArray()
    (0 until arr.length()).map { i -> arr.getJSONObject(i).let { CaptionWord(it.optString("text"), it.optDouble("start", 0.0), it.optDouble("end", 0.0)) } }
}.getOrDefault(emptyList())

private fun rebuildCaptionJson(old: List<CaptionWord>, edited: String): String {
    val tokens = edited.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
    val first = old.firstOrNull()?.start ?: 0.0
    val last = old.lastOrNull()?.end ?: first
    val words = if (tokens.size == old.size) tokens.mapIndexed { i, text -> JSONObject().put("text", text).put("start", old[i].start).put("end", old[i].end) }
    else tokens.mapIndexed { i, text ->
        val span = (last - first).coerceAtLeast(0.0)
        val start = first + span * i / tokens.size.coerceAtLeast(1)
        val end = first + span * (i + 1) / tokens.size.coerceAtLeast(1)
        JSONObject().put("text", text).put("start", start).put("end", end)
    }
    JSONObject().put("words", JSONArray(words)).toString()
}
